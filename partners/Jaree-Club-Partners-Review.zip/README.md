# Jaree Club — Partner presentation

Arabic and English interactive presentation for prospective partners. A developing concept, not a product acceptance report or an announcement of commercial partnerships.

## Open

- Arabic: https://nfatjaree.github.io/jaree-club-presentation/partners/
- English: https://nfatjaree.github.io/jaree-club-presentation/partners/en.html

The public presentation requires no account. It has no analytics, forms, application API calls or external runtime dependencies.

## Edit and build

1. Edit the product copy in `content/ar.json` and `content/en.json`.
2. Edit interactions in `src/app.js`, styles in `src/style.css` and page structure in `scripts/build.py`.
3. Run `python3 scripts/build.py`.
4. Run `python3 -m http.server 3339 --bind 127.0.0.1 --directory dist` and open the local page.
5. Run `python3 scripts/export-offline.py` to regenerate copy documents, the offline ZIP and the complete review bundle.

No dependency installation is required. `dist/` is the generated public site. Keep the two offline HTML files in the same directory so language switching works.

## Structure

Eight sections: introduction, partner value, membership, application and launch, benefit options, verification, reporting and integration. Notion, Regus and Hilton are labelled illustrative examples. Selecting an example carries it into verification and reporting. Confirmation adds one illustrative use; repeating it does not add another. Language switching preserves the selection, verification stage and current section.

## Boundaries

- Membership and benefit rules define eligibility; a shared code alone does not prevent forwarding.
- Code allocation or display is distinct from a confirmed redemption.
- Reporting omits member names; authorised verification may require scoped data.
- Integration is optional and needs preparation and testing against the partner's actual system.
- Examples, membership artwork, figures and simulated actions are not real accounts or transactions.

## Assets

The supplied visual reference is https://nfatjaree.github.io/jaree-club-presentation/ . Jaree logos, demonstration card artwork and illustrative brand logos are retained from that reference. IBM Plex Sans Arabic fonts and their licence are bundled in `dist/assets/`. No new commercial partnership or brand endorsement is implied.

## Verification

Both languages inspected in a browser at 936px and 390px. Observed no horizontal page overflow. Checked application stages, all three benefit methods, verification/confirmation/repeat/reset, reporting update, chapter navigation, language continuity and motion controls. Assets/anchors resolve; IDs are unique; JavaScript syntax passes. A bounded independent source and copy review found no material unresolved issue.

Offline files are statically checked for embedded runtime resources; their served equivalent was exercised. Direct local-file browser execution and physical phones, Safari and Firefox have not been verified. This is presentation testing, not Jaree application acceptance.

The original root presentation and all Jaree application environments remain outside this project.
