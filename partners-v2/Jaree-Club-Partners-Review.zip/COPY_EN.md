# Jaree Club | Partner experience

Editable source: `content/en.json`

**lang**

en

**dir**

ltr

**title**

Jaree Club | Partner experience

**description**

Explore the Jaree Club partner journey: application, benefit launch, redemption, reporting and integration.

**ui.club**

Jaree Club

**ui.partners**

For partners

**ui.concept**

Concept preview

**ui.menu**

Contents

**ui.skip**

Skip to content

**ui.pause**

Pause motion

**ui.play**

Enable motion

**ui.fullscreen**

Full screen

**ui.exitFullscreen**

Exit full screen

**ui.previous**

Previous section

**ui.next**

Next section

**ui.home**

Presentation home

**ui.language**

العربية

**ui.alternate**

index.html

**ui.nextLabel**

Next

**ui.backTop**

Back to the beginning

**ui.example**

Illustrative example

**ui.figures**

Illustrative figures

**ui.brandNote**

Illustrative examples only. These brands are not announced partners, and the benefits are not real offers.

**ui.continue**

Continue the example

**ui.memberName**

Member name

**ui.memberOf**

Member of

**ui.membership**

Membership

**ui.investor**

Investor

**ui.startup**

Startup

**nav[0]**

Overview

**nav[1]**

Partner value

**nav[2]**

Membership

**nav[3]**

Application & launch

**nav[4]**

Redemption options

**nav[5]**

Verification

**nav[6]**

Reporting

**nav[7]**

Integration

**intro.eyebrow**

The partner experience

**intro.heading[0]**

Jaree Club

**intro.heading[1]**

for partners

**intro.lead**

Offer benefits to investors and startups, with clear controls for publication, redemption and reporting.

**intro.action**

Discover the value for partners

**intro.note**

A concept in development. Interfaces, examples and figures are illustrative.

**intro.float1[0]**

Digital subscription

**intro.float1[1]**

A code allocated to the member

**intro.float2[0]**

Workspace access

**intro.float2[1]**

Membership card verification

**members.title**

Membership and eligibility

**members.lead**

Membership is linked to an approved Jaree account. Partners choose the audience for each benefit: investors, startups or both.

**members.groups[0][0]**

Startups

**members.groups[0][1]**

Membership held by a company representative, with benefits for business needs.

**members.groups[1][0]**

Investors

**members.groups[1][1]**

Services, experiences and benefits relevant to their work and interests.

**members.window**

Member account

**members.heading**

Membership card and benefits

**members.body**

Members find their card, eligible benefits and redemption terms in their account.

**members.foot**

Checking a card does not automatically record a redemption.

**members.next**

Application and launch

**join.title**

From application to publication

**join.lead**

Once admitted, partners submit their profile and initial benefits in one launch package.

**join.stages[0].name**

Apply

**join.stages[0].summary**

Organisation and contact details

**join.stages[0].title**

Introduce the organisation

**join.stages[0].body**

Provide the organisation name, activity, contact details and website, if any. The application is saved while being prepared.

**join.stages[0].status**

Draft

**join.stages[0].rows[0]**

Organisation details

**join.stages[0].rows[1]**

Activity and website

**join.stages[0].rows[2]**

Contact details

**join.stages[1].name**

Admission

**join.stages[1].summary**

A clear decision and any feedback

**join.stages[1].title**

Partnership review

**join.stages[1].body**

Jaree reviews the application. The account shows the decision and any changes required.

**join.stages[1].status**

In review

**join.stages[1].rows[0]**

Details reviewed

**join.stages[1].rows[1]**

Admission decision

**join.stages[1].rows[2]**

Specific feedback

**join.stages[2].name**

Prepare benefits

**join.stages[2].summary**

Content, terms and redemption

**join.stages[2].title**

Prepare the launch package

**join.stages[2].body**

Add the brand profile, images and benefits, then preview the content before submitting.

**join.stages[2].status**

In preparation

**join.stages[2].rows[0]**

Profile and images

**join.stages[2].rows[1]**

Benefits and terms

**join.stages[2].rows[2]**

Content preview

**join.stages[3].name**

Review and publish

**join.stages[3].summary**

Profile and initial benefits together

**join.stages[3].title**

Launch approved content

**join.stages[3].body**

Jaree reviews the launch package. The profile and initial benefits are published together after approval.

**join.stages[3].status**

Awaiting approval

**join.stages[3].rows[0]**

One launch package

**join.stages[3].rows[1]**

Jaree review

**join.stages[3].rows[2]**

Approved content published

**join.foot**

Admission does not automatically publish content.

**join.next**

Explore redemption options

**benefit.title**

Redemption that suits your business

**benefit.lead**

Define where members redeem a benefit, what they present and how the use is confirmed.

**benefit.tabs[0]**

Online

**benefit.tabs[1]**

In person

**benefit.tabs[2]**

Service or experience

**benefit.audience**

Eligible audience

**benefit.method**

Redemption method

**benefit.controls**

Defined by the partner

**benefit.controlLabels[0]**

Audience

**benefit.controlLabels[1]**

Dates

**benefit.controlLabels[2]**

Usage limits

**benefit.controlLabels[3]**

Terms

**benefit.codeTitle**

Code options

**benefit.codeBody**

A shared code, individual codes supplied by the partner, Jaree vouchers, or codes issued by the partner’s system.

**benefit.action**

Continue to verification

**benefit.methods[0].id**

digital

**benefit.methods[0].brand**

Notion

**benefit.methods[0].category**

Work tools

**benefit.methods[0].title**

A digital subscription for members

**benefit.methods[0].body**

An example subscription activated on the partner’s website.

**benefit.methods[0].audience**

Startups

**benefit.methods[0].method**

Individual code

**benefit.methods[0].heading**

From the member account to the partner’s website

**benefit.methods[0].steps[0]**

The member reads the benefit and terms in Jaree.

**benefit.methods[0].steps[1]**

They receive their allocated code.

**benefit.methods[0].steps[2]**

They use it on the partner’s website.

**benefit.methods[0].note**

Redemption is recorded when the partner’s system confirms it, if integration is enabled.

**benefit.methods[0].token**

Member code

**benefit.methods[0].verify**

Verify code

**benefit.methods[0].unit**

One use

**benefit.methods[0].remaining**

0

**benefit.methods[0].remainingLabel**

Remaining uses

**benefit.methods[0].verification**

Valid code and eligible member. No redemption has been recorded.

**benefit.methods[0].place**

In the partner’s system

**benefit.methods[1].id**

venue

**benefit.methods[1].brand**

Regus

**benefit.methods[1].category**

Workspaces

**benefit.methods[1].title**

Two days at a workspace

**benefit.methods[1].body**

An example benefit at locations selected by the partner.

**benefit.methods[1].audience**

Startups

**benefit.methods[1].method**

Membership card

**benefit.methods[1].heading**

Verify at the point of use

**benefit.methods[1].steps[0]**

The member checks the locations and terms.

**benefit.methods[1].steps[1]**

They present their card for an eligibility check.

**benefit.methods[1].steps[2]**

Authorised staff confirm the redemption.

**benefit.methods[1].note**

You can start with Jaree’s verification page without a technical integration.

**benefit.methods[1].token**

Membership card

**benefit.methods[1].verify**

Verify membership

**benefit.methods[1].unit**

Two days

**benefit.methods[1].remaining**

1

**benefit.methods[1].remainingLabel**

Days remaining

**benefit.methods[1].verification**

Valid membership and an eligible benefit. Two days remain; no redemption is recorded.

**benefit.methods[1].place**

On Jaree’s verification page

**benefit.methods[2].id**

experience

**benefit.methods[2].brand**

Hilton

**benefit.methods[2].category**

Hospitality and experiences

**benefit.methods[2].title**

A hospitality experience for members

**benefit.methods[2].body**

An example experience subject to the partner’s terms and availability.

**benefit.methods[2].audience**

Investors and startups

**benefit.methods[2].method**

Jaree voucher

**benefit.methods[2].heading**

Present a voucher to redeem

**benefit.methods[2].steps[0]**

The member checks the experience and booking terms.

**benefit.methods[2].steps[1]**

They receive their voucher in Jaree.

**benefit.methods[2].steps[2]**

The voucher is checked, then redemption is confirmed.

**benefit.methods[2].note**

Receiving a voucher does not mean it has been redeemed.

**benefit.methods[2].token**

Member voucher

**benefit.methods[2].verify**

Verify voucher

**benefit.methods[2].unit**

One use

**benefit.methods[2].remaining**

0

**benefit.methods[2].remainingLabel**

Remaining uses

**benefit.methods[2].verification**

Valid voucher and eligible member. No redemption has been recorded.

**benefit.methods[2].place**

On Jaree’s verification page

**benefit.limit**

Usage limit

**trust.title**

Verification and redemption

**trust.lead**

Benefit details may be public. Eligible members obtain codes under the benefit’s terms.

**trust.rules[0]**

Valid membership

**trust.rules[1]**

Defined audience

**trust.rules[2]**

Dates and usage limits

**trust.note**

Use verification or individual codes with suitable controls. A shared code alone does not prevent forwarding.

**trust.demo**

Redemption example

**trust.initial**

Check eligibility first. Nothing is recorded at this stage.

**trust.eligible**

Eligible to redeem

**trust.confirm**

Confirm redemption

**trust.confirmed**

Redemption recorded

**trust.result**

The remaining allowance and activity record have been updated.

**trust.repeat**

Repeat confirmation request

**trust.repeated**

Already recorded

**trust.repeatNote**

The same result is returned without recording another use.

**trust.reset**

Restart the example

**trust.seeActivity**

View the activity record

**trust.demoNote**

An interactive example. No real transaction is recorded.

**trust.reference**

Reference

**insights.title**

Monitoring and control

**insights.lead**

Benefit status, code availability and confirmed redemptions in one workspace.

**insights.dashboard**

Benefit activity

**insights.metrics[0][0]**

Codes allocated

**insights.metrics[0][1]**

Given to members, not counted as uses

**insights.metrics[1][0]**

Confirmed redemptions

**insights.metrics[1][1]**

Recorded only after confirmation

**insights.metrics[2][0]**

Available codes

**insights.metrics[2][1]**

Ready for new members

**insights.chart**

Confirmed redemptions

**insights.period**

Six illustrative weeks

**insights.history**

Recent activity

**insights.today**

Today

**insights.yesterday**

Yesterday

**insights.rows[0][0]**

Redemption confirmed

**insights.rows[0][1]**

DEMO-024

**insights.rows[1][0]**

Code displayed

**insights.rows[1][1]**

Use not confirmed

**insights.rows[2][0]**

Redemption reversed

**insights.rows[2][1]**

Record retained

**insights.newRow**

from the example

**insights.principles[0][0]**

Clear measurement

**insights.principles[0][1]**

Allocating or displaying a code does not establish redemption.

**insights.principles[1][0]**

Privacy-aware reporting

**insights.principles[1][1]**

Activity reports omit names; verification data is limited to authorised checks.

**insights.principles[2][0]**

Benefit controls

**insights.principles[2][1]**

Submit content changes for review and pause new claims when needed.

**insights.next**

Explore integration options

**connect.title**

Integration to suit your needs

**connect.lead**

Start with Jaree’s verification page, or connect your system after preparation and testing.

**connect.system**

Partner system

**connect.systemNote**

Commerce, booking, subscriptions or a custom system

**connect.clubNote**

Membership, eligibility and redemption records

**connect.optional**

Optional integration

**connect.functions[0]**

Verification

**connect.functions[1]**

Code issuance

**connect.functions[2]**

Redemption confirmation

**connect.steps[0][0]**

Define the scope

**connect.steps[0][1]**

What your system handles and what stays in Jaree.

**connect.steps[1][0]**

Prepare and test access

**connect.steps[1][1]**

Scoped permissions and revocable keys.

**connect.steps[2][0]**

Monitor requests and results

**connect.steps[2][1]**

Retry without duplicating the transaction.

**connect.detailTitle**

Integration requirements

**connect.detail**

Endpoints, code issuance, confirmation and failure handling depend on the partner’s system. This presentation does not assume a ready-made connector to any specific platform.

**connect.closing**

Define the first benefit

**connect.closingBody**

Four points to agree before launch.

**connect.closingLabels[0]**

Benefit

**connect.closingLabels[1]**

Audience

**connect.closingLabels[2]**

Terms

**connect.closingLabels[3]**

Redemption method

**value.title**

Why partner with Jaree Club?

**value.lead**

Introduce your benefits to a focused audience and build your brand’s presence within the Jaree community.

**value.items[0][0]**

A focused audience

**value.items[0][1]**

A trusted investor community, including high-net-worth individuals, alongside startups seeking services that support their growth.

**value.items[1][0]**

Visibility on Jaree’s website

**value.items[1][1]**

Your brand and approved benefits appear in Jaree Club, with offer details, redemption instructions and your links.

**value.items[2][0]**

Special placement for distinctive benefits

**value.items[2][1]**

Partners offering distinctive benefits may receive featured placement within Jaree Club, based on the benefit’s value and relevance to members.

**value.next**

Meet the Jaree Club audience
