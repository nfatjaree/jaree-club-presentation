from pathlib import Path
import json
import hashlib
from html import escape

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / 'dist'
IDS = ['intro', 'about', 'value', 'members', 'join', 'benefit', 'trust', 'insights', 'connect', 'scenarios']

def e(text):
    return escape(str(text), quote=True)

def icon(name, cls=''):
    return f'<svg class="{cls}" aria-hidden="true"><use href="#i-{name}"/></svg>'

def card(c, startup=False):
    u = c['ui']
    return f'''<div class="membership-card {'small-card' if startup else 'hero-card'}">
      <div class="card-top"><div>{e(u['memberOf'])}<br><b>{e(u['club'])}</b></div><img src="assets/jaree-white.svg" alt=""></div>
      <div class="card-color {'teal' if startup else ''}"><strong>{e(u['memberName'])}</strong><span>{e(u['membership'])}<b>{e(u['startup'] if startup else u['investor'])}</b></span></div>
      <div class="card-qr"><img src="assets/qr.svg" alt=""><small>DEMO · JAREE CLUB</small></div>
    </div>'''

def build(c):
    u = c['ui']; ar = c['lang']=='ar'
    css_version = hashlib.sha256((ROOT/'src/style.css').read_bytes()).hexdigest()[:12]
    js_version = hashlib.sha256((ROOT/'src/app.js').read_bytes()).hexdigest()[:12]
    def heading(key):
        n = IDS.index(key)
        return f'<div class="section-heading reveal"><p class="eyebrow">{n+1:02d} / {e(c["nav"][n])}</p><h2 id="{key}-title">{e(c[key]["title"])}</h2><p class="lead">{e(c[key]["lead"])}</p></div>'
    nav = ''.join(f'<a href="#{sid}"><b>{i+1:02d}</b><span>{e(c["nav"][i])}</span></a>' for i,sid in enumerate(IDS))
    intro=c['intro']; members=c['members']; join=c['join']; benefit=c['benefit']; trust=c['trust']; insights=c['insights']; connect=c['connect']; method=benefit['methods'][0]
    groups=''.join(f'<article><span>{i+1:02d}</span><h3>{e(title)}</h3><p>{e(body)}</p></article>' for i,(title,body) in enumerate(members['groups']))
    stages=''.join(f'<li><button type="button" class="journey-stage" data-stage="{i}" aria-pressed="{str(i==0).lower()}" aria-controls="stage-panel"><span class="step-number">{i+1}</span><strong>{e(s["name"])}</strong><span>{e(s["summary"])}</span></button></li>' for i,s in enumerate(join['stages']))
    tabs=''.join(f'<button role="tab" id="tab-{m["id"]}" data-method="{m["id"]}" aria-controls="method-panel" aria-selected="{str(i==0).lower()}" tabindex="{0 if i==0 else -1}">{icon(["globe","place","spark"][i])}<span>{e(benefit["tabs"][i])}</span></button>' for i,m in enumerate(benefit['methods']))
    metrics=''.join(f'<div><span>{e(text[0])}</span><strong id="metric-{i}">{[48,24,72][i]}</strong><small>{e(text[1])}</small></div>' for i,text in enumerate(insights['metrics']))
    chart=''.join(f'<div><span id="bar-value-{i}">{n}</span><i id="bar-{i}" style="--bar:{n/8*100}%"></i><small>{i+1:02d}</small></div>' for i,n in enumerate([2,3,4,3,5,7]))
    activity=''.join(f'<div class="activity-row"><span class="event-dot {"neutral-dot" if i else ""}"></span><div><b>{e(row[0])}</b><small><bdi>{e(row[1])}</bdi></small></div><span>{e(insights["today"] if i<2 else insights["yesterday"])}</span></div>' for i,row in enumerate(insights['rows']))
    principles=''.join(f'<div><b>{e(title)}</b><p>{e(body)}</p></div>' for title,body in insights['principles'])
    connection_steps=''.join(f'<article><span>{i+1}</span><div><h3>{e(title)}</h3><p>{e(body)}</p></div></article>' for i,(title,body) in enumerate(connect['steps']))
    embedded=json.dumps(c,ensure_ascii=False).replace('<','\\u003c')
    page=f'''<!doctype html>
<html lang="{c['lang']}" dir="{c['dir']}">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#111112"><meta name="description" content="{e(c['description'])}">
<title>{e(c['title'])}</title>
<link rel="icon" type="image/svg+xml" href="assets/jaree.svg">
<link rel="alternate" hreflang="ar" href="index.html"><link rel="alternate" hreflang="en" href="en.html">
<link rel="stylesheet" href="assets/fonts.css"><link rel="stylesheet" href="style.css?v={css_version}">
<script src="app.js?v={js_version}" defer></script>
</head><body>
<a class="skip-link" href="#main">{e(u['skip'])}</a>
{(ROOT/'src/icons.svg').read_text()}
<header class="site-header">
<a class="wordmark" href="#intro" aria-label="{e(u['home'])}"><img src="assets/jaree.svg" alt="{e(u['club'])}" width="66" height="38"><span>{e(u['club'])}<small>{e(u['partners'])} · {e(u['concept'])}</small></span></a>
<div class="header-tools">
<div class="language-group" aria-label="{'اللغة' if ar else 'Language'}">{('<a id="language-switch" class="language-switch" href="en.html" lang="en">English</a><span class="language-current" lang="ar" aria-current="true">العربية</span>' if ar else '<span class="language-current" lang="en" aria-current="true">English</span><a id="language-switch" class="language-switch" href="index.html" lang="ar" dir="rtl">العربية</a>')}</div>
<details class="chapter-menu"><summary aria-label="{e(u['menu'])}"><span class="menu-word">{e(u['menu'])}</span>{icon('menu','menu-icon')}</summary><div class="menu-panel"><nav aria-label="{e(u['menu'])}">{nav}</nav><div class="menu-options">
<button id="motion-toggle" aria-label="{e(u['pause'])}" aria-pressed="false">{icon('pause')}<span id="motion-label">{e(u['pause'])}</span></button>
<button class="fullscreen-control" id="fullscreen" aria-label="{e(u['fullscreen'])}">{icon('expand')}<span id="fullscreen-label">{e(u['fullscreen'])}</span></button>
<a href="Jaree-Club-Partners-{'AR' if ar else 'EN'}.pdf" class="pdf-download">{icon('arrow')}<span>{e(u['download'])}</span></a>
</div></div></details>
</div></header>
<main id="main">
<section class="chapter hero" id="intro" data-title="{e(c['nav'][IDS.index('intro')])}" aria-labelledby="intro-title">
<div class="hero-copy reveal"><p class="eyebrow">{e(intro['eyebrow'])}</p><h1 id="intro-title">{e(intro['heading'][0])}<br><span>{e(intro['heading'][1])}</span></h1><p class="lead">{e(intro['lead'])}</p><a class="button primary" href="#about">{e(intro['action'])}{icon('arrow')}</a><p class="concept-note">{e(intro['note'])}</p></div>
<div class="hero-art reveal"><div class="art-grid"></div><div class="red-light"></div><div class="art-label">{e(u['club'])}</div>{card(c)}
<div class="floating-benefit notion-float"><span class="logo-tile"><img src="assets/notion.svg" alt="Notion"></span><div><b>{e(intro['float1'][0])}</b><small>{e(intro['float1'][1])}</small></div></div>
<div class="floating-benefit regus-float"><span class="logo-tile"><img src="assets/regus.svg" alt="Regus"></span><div><b>{e(intro['float2'][0])}</b><small>{e(intro['float2'][1])}</small></div></div>
<span class="art-foot">{e(u['example'])}</span></div></section>
<section class="chapter about" id="about" data-title="{e(c['nav'][1])}" aria-labelledby="about-title">
{heading('about')}<div class="about-proof reveal"><div class="admission-figures">{''.join(f'<div class="admission-stat"><strong dir="ltr">{e(value)}</strong><span>{e(label)}</span></div>' for value,label in c['about']['stats'])}<p class="admission-selection">{e(c['about']['selection'])}</p></div><p class="source-note">{e(c['about']['source'])}</p></div><div class="about-audiences reveal">{''.join(f'<article><h3>{e(title)}</h3><p>{e(body)}</p></article>' for title,body in c['about']['items'])}</div></section>
<section class="chapter partner-value" id="value" data-title="{e(c['nav'][2])}" aria-labelledby="value-title">
{heading('value')}<div class="value-layout reveal"><div class="partner-value-grid">{''.join(f'<article><span class="value-number">{i+1:02d}</span><div><h3>{e(title)}</h3><p>{e(body)}</p></div></article>' for i,(title,body) in enumerate(c['value']['items']))}</div>
<div class="brand-showcase"><div class="showcase-top"><b>{e(c['value']['showcase']['title'])}</b><span>{e(u['example'])}</span></div><a class="featured-brand" href="#benefit" data-showcase="digital"><div class="featured-art"><div class="showcase-notebook"><i></i><i></i><i></i><div><span></span><span></span><span></span></div></div><img src="assets/notion.svg" alt="Notion"><span class="featured-tag">{e(c['value']['showcase']['featured'])}</span></div><div class="featured-copy"><span>Notion</span><h3>{e(c['value']['showcase']['notion'])}</h3><small>{e(c['value']['showcase']['audience'])}</small><b>{e(c['value']['showcase']['view'])}{icon('arrow')}</b></div></a><div class="secondary-brands"><a href="#benefit" data-showcase="venue"><img src="assets/regus.svg" alt="Regus"><span>{e(c['value']['showcase']['regus'])}</span>{icon('arrow')}</a><a href="#benefit" data-showcase="experience"><img src="assets/hilton.svg" alt="Hilton"><span>{e(c['value']['showcase']['hilton'])}</span>{icon('arrow')}</a></div></div></div><p class="brand-note">{e(u['brandNote'])}</p></section>
<section class="chapter members" id="members" data-title="{e(c['nav'][IDS.index('members')])}" aria-labelledby="members-title">
{heading('members')}<div class="audience-layout reveal"><div class="audience-list">{groups}</div><div class="member-window"><div class="window-title"><span>{e(members['window'])}</span><span class="outline-tag">{e(u['example'])}</span></div><div class="member-window-body"><div><h3>{e(members['heading'])}</h3><p>{e(members['body'])}</p></div>{card(c,True)}</div><div class="member-window-foot">{e(members['foot'])}</div></div></div></section>
<section class="chapter join" id="join" data-title="{e(c['nav'][IDS.index('join')])}" aria-labelledby="join-title">
{heading('join')}<ol class="journey reveal">{stages}</ol>
<div class="stage-panel reveal" id="stage-panel" aria-live="polite"><div><span class="small-label" id="stage-status">{e(join['stages'][0]['status'])}</span><h3 id="stage-title">{e(join['stages'][0]['title'])}</h3><p id="stage-body">{e(join['stages'][0]['body'])}</p></div><ul id="stage-rows">{''.join(f'<li>{icon("check")}<span>{e(x)}</span></li>' for x in join['stages'][0]['rows'])}</ul></div>
<p class="section-note">{e(join['foot'])}</p></section>
<section class="chapter benefit" id="benefit" data-title="{e(c['nav'][IDS.index('benefit')])}" aria-labelledby="benefit-title">
{heading('benefit')}<div class="benefit-selector reveal"><div class="method-tabs" role="tablist" aria-label="{e(benefit['title'])}">{tabs}</div><div class="method-content" id="method-panel" role="tabpanel" aria-labelledby="tab-digital"><article class="offer-preview"><div class="offer-cover"><img id="offer-logo" src="assets/notion.svg" alt="Notion"><div class="notion-graphic" id="offer-graphic"><div class="note-sheet"><span></span><span></span><div><i></i><i></i><i></i></div><span></span></div></div><span class="cover-label">{e(u['example'])}</span></div><div class="offer-body"><span class="small-label" id="offer-brand">Notion / {e(method['category'])}</span><h3 id="offer-title">{e(method['title'])}</h3><p id="offer-body">{e(method['body'])}</p><dl><div><dt>{e(benefit['audience'])}</dt><dd id="offer-audience">{e(method['audience'])}</dd></div><div><dt>{e(benefit['method'])}</dt><dd id="offer-method">{e(method['method'])}</dd></div><div><dt>{e(benefit['limit'])}</dt><dd id="offer-limit">{e(method['unit'])}</dd></div></dl></div></article><div class="method-explanation"><h3 id="method-heading">{e(method['heading'])}</h3><ol id="method-steps">{''.join(f'<li><span>{i+1}</span>{e(x)}</li>' for i,x in enumerate(method['steps']))}</ol><p class="method-note" id="method-note">{e(method['note'])}</p><div class="your-controls"><span class="small-label">{e(benefit['controls'])}</span><div>{''.join(f'<span>{e(x)}</span>' for x in benefit['controlLabels'])}</div></div><a class="button primary flow-link" href="#trust">{e(benefit['action'])}{icon('arrow')}</a></div></div></div>
<p class="brand-note">{e(u['brandNote'])}</p><div class="code-options"><b>{e(benefit['codeTitle'])}</b><p>{e(benefit['codeBody'])}</p></div></section>
<section class="chapter trust" id="trust" data-title="{e(c['nav'][IDS.index('trust')])}" aria-labelledby="trust-title">
<div class="trust-copy reveal"><p class="eyebrow light">{IDS.index('trust')+1:02d} / {e(c['nav'][IDS.index('trust')])}</p><h2 id="trust-title">{e(trust['title'])}</h2><p class="lead">{e(trust['lead'])}</p><div class="trust-rules">{''.join(f'<span>{icon("check")}{e(x)}</span>' for x in trust['rules'])}</div><p class="trust-footnote">{e(trust['note'])}</p></div>
<div class="verification-demo reveal" role="region" aria-label="{e(trust['demo'])}"><div class="window-title"><span id="verification-place">{e(method['place'])}</span><img id="verification-logo" src="assets/notion.svg" alt="Notion"></div><div class="verification-content"><div class="verification-state" id="verification-state" aria-live="polite" aria-atomic="true"><div class="verification-symbol">{icon('key')}</div><span class="small-label" id="verification-token">{e(method['token'])}</span><h3 id="verification-title">{e(method['title'])}</h3><p id="verification-body">{e(trust['initial'])}</p><div class="verification-detail" id="verification-detail" hidden></div></div><div class="verification-action"><button class="button primary" id="verify-button">{e(method['verify'])}{icon('arrow')}</button><a class="button primary" id="activity-link" href="#insights" hidden>{e(trust['seeActivity'])}{icon('arrow')}</a><button class="text-button" id="repeat-button" hidden>{e(trust['repeat'])}</button><button class="text-button" id="verify-reset" hidden>{e(trust['reset'])}</button></div><div class="demo-only">{e(trust['demoNote'])}</div></div></div>
</section>
<section class="chapter insights" id="insights" data-title="{e(c['nav'][IDS.index('insights')])}" aria-labelledby="insights-title">
{heading('insights')}<div class="dashboard-preview reveal"><div class="dashboard-header"><div>{icon('chart')}<b>{e(insights['dashboard'])}</b></div><span class="outline-tag">{e(u['figures'])}</span></div><div class="metrics">{metrics}</div><div class="dashboard-lower"><div class="chart-area"><div class="chart-title"><b>{e(insights['chart'])}</b><span>{e(insights['period'])}</span></div><div class="bar-chart" role="img" aria-label="{e(insights['chart'])}: 2, 3, 4, 3, 5, 7">{chart}</div></div><div class="activity-example"><b>{e(insights['history'])}</b><div class="activity-row new-activity" id="new-activity" hidden><span class="event-dot"></span><div><b id="new-activity-title">{e(insights['rows'][0][0])}</b><small id="new-activity-detail"></small></div><span>{e(insights['today'])}</span></div>{activity}</div></div></div>
<div class="insight-principles reveal">{principles}</div></section>
<section class="chapter connect" id="connect" data-title="{e(c['nav'][IDS.index('connect')])}" aria-labelledby="connect-title">
{heading('connect')}<div class="connection-layout reveal"><div class="connection-map"><div class="system-node"><span class="system-mark">{icon('globe')}</span><b>{e(connect['system'])}</b><small>{e(connect['systemNote'])}</small></div><div class="connection-line" aria-hidden="true"><i></i><span>{e(connect['optional'])}</span></div><div class="system-node jaree-node"><img src="assets/jaree-white.svg" alt="{e(u['club'])}"><b>{e(u['club'])}</b><small>{e(connect['clubNote'])}</small></div><div class="connection-functions">{''.join(f'<span>{e(x)}</span>' for x in connect['functions'])}</div></div><div class="connection-steps">{connection_steps}</div></div>
<details class="technical-detail reveal"><summary>{e(connect['detailTitle'])}<span aria-hidden="true">+</span></summary><div><p>{e(connect['detail'])}</p></div></details>
</section>
<section class="chapter scenarios" id="scenarios" data-title="{e(c['nav'][-1])}" aria-labelledby="scenarios-title">
{heading('scenarios')}<div class="scenario-workspace reveal"><div class="scenario-tabs" role="tablist" aria-label="{e(c['scenarios']['title'])}">{''.join(f'<button role="tab" id="scenario-tab-{x["id"]}" data-scenario="{x["id"]}" aria-selected="{str(i==0).lower()}" aria-controls="scenario-panel" tabindex="{0 if i==0 else -1}"><span>{i+1:02d}</span>{e(x["title"])}</button>' for i,x in enumerate(c['scenarios']['items']))}</div><div id="scenario-panel" role="tabpanel" aria-labelledby="scenario-tab-verify"><div class="technical-flow-heading"><span id="scenario-direction">{e(c['scenarios']['items'][0]['direction'])}</span><span class="transport-label" dir="ltr">HTTPS / JSON</span></div><p id="scenario-body">{e(c['scenarios']['items'][0]['body'])}</p><ol class="scenario-flow" id="scenario-flow">{''.join(f'<li><span>{i+1:02d}</span><b>{e(text)}</b></li>' for i,text in enumerate(c['scenarios']['items'][0]['steps']))}</ol><p class="scenario-summary" id="scenario-summary">{e(c['scenarios']['items'][0]['summary'])}</p><details class="api-disclosure"><summary>{e(c['scenarios']['technicalLabel'])}<span aria-hidden="true">+</span></summary><div class="api-disclosure-body"><div class="api-base"><span>{e(c['scenarios']['baseLabel'])}</span><code dir="ltr">/api/v1/club/partner-api</code></div><div class="api-exchange"><div class="api-request"><span>{e(c['scenarios']['requestLabel'])}</span><pre dir="ltr"><code id="scenario-request">{e(c['scenarios']['items'][0]['request'])}</code></pre></div><div class="api-response"><span>{e(c['scenarios']['responseLabel'])}</span><pre dir="ltr"><code id="scenario-response">{e(c['scenarios']['items'][0]['response'])}</code></pre><p id="scenario-outcome">{e(c['scenarios']['items'][0]['outcome'])}</p></div></div><p id="scenario-detail">{e(c['scenarios']['items'][0]['detail'])}</p><small class="technical-example-note">{e(c['scenarios']['exampleNote'])}</small></div></details><p class="scenario-note">{icon('check')}{e(c['scenarios']['note'])}</p></div></div>
<div class="closing-panel reveal"><div><span class="dash"></span><h3>{e(connect['closing'])}</h3><p>{e(connect['closingBody'])}</p></div><div class="closing-labels">{''.join(f'<span>{i+1:02d} <b>{e(x)}</b></span>' for i,x in enumerate(connect['closingLabels']))}</div></div></section>
</main><footer class="presentation-controls" aria-label="{e(u['menu'])}"><span class="progress-label"><span class="progress-count" dir="ltr"><b id="current-number">01</b> / {len(IDS):02d}</span><span id="current-title">{e(c['nav'][0])}</span></span><div class="progress-track" aria-hidden="true"><span id="progress-fill"></span></div><div class="chapter-buttons"><button id="previous" aria-label="{e(u['previous'])}" disabled>{icon('arrow','reverse')}</button><button id="next-chapter" aria-label="{e(u['next'])}">{icon('arrow')}</button></div></footer>
<script type="application/json" id="presentation-copy">{embedded}</script>
</body></html>'''
    return page

for lang,filename in [('ar','index.html'),('en','en.html')]:
    c=json.loads((ROOT/'content'/f'{lang}.json').read_text())
    (DIST/filename).write_text(build(c))
(DIST/'style.css').write_text((ROOT/'src/style.css').read_text())
(DIST/'app.js').write_text((ROOT/'src/app.js').read_text())
print('Built Arabic and English presentations')
