#!/usr/bin/env python3
"""Build the bilingual partner handout from the presentation's shared content."""
from pathlib import Path
from html import escape
import argparse
import json
import shutil
import os

os.environ.setdefault('DYLD_FALLBACK_LIBRARY_PATH', '/opt/homebrew/lib')
from weasyprint import HTML
import cairosvg
import xml.etree.ElementTree as ET

SOURCE = Path(__file__).resolve().parents[1]
ROOT = SOURCE.parent
OUTPUT = SOURCE / 'pdf'
FONT_SOURCE = SOURCE / 'dist' / 'assets'
PAGE_COUNT = 7
PUBLIC_SITE = 'https://nfatjaree.github.io/jaree-club-presentation/partners-v2/'

def e(value):
    return escape(str(value), quote=True)

def img(name, cls='', alt=''):
    return f'<img src="assets/{e(name)}" class="{e(cls)}" alt="{e(alt)}">'

def setup_assets():
    target = OUTPUT / 'assets'
    target.mkdir(parents=True, exist_ok=True)
    for name in ['plex-arabic-0.ttf','plex-arabic-1.ttf','plex-arabic-2.ttf','plex-arabic-3.ttf','FONT-LICENSE.txt']:
        shutil.copy2(FONT_SOURCE / name, target / name)
    for name in ['jaree.svg','jaree-white.svg','qr.svg','red-art.svg','teal-art.svg','notion.svg','regus.svg','hilton.svg']:
        shutil.copy2(SOURCE / 'dist' / 'assets' / name, target / name)
    # Rasterise the supplied gradient artwork for consistent print rendering.
    artwork=ET.fromstring((target/'red-art.svg').read_text())
    artwork.attrib.pop('style',None)
    artwork.set('width','1539');artwork.set('height','891')
    cairosvg.svg2png(bytestring=ET.tostring(artwork), write_to=str(target/'red-art.png'), output_width=920, output_height=540)

CSS = r'''
@font-face{font-family:Plex;src:url(assets/plex-arabic-0.ttf);font-weight:400}
@font-face{font-family:Plex;src:url(assets/plex-arabic-1.ttf);font-weight:500}
@font-face{font-family:Plex;src:url(assets/plex-arabic-2.ttf);font-weight:600}
@font-face{font-family:Plex;src:url(assets/plex-arabic-3.ttf);font-weight:700}
@page{size:A4;margin:0}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:Plex,sans-serif;font-size:9.7pt;line-height:1.55;color:#111112;background:#fff}
h1,h2,h3,p{margin:0}
h1,h2,h3{font-weight:600;letter-spacing:-.015em;line-height:1.2}
.page{width:210mm;height:297mm;padding:15mm 16mm 20mm;position:relative;break-after:page}
.page:last-child{break-after:auto}
.run{display:flex;justify-content:space-between;align-items:center;height:10mm;margin-bottom:9mm;color:#65686c;font-size:7.8pt}
.brand{display:flex;align-items:center;gap:3.3mm;width:85mm;flex-shrink:0}.brand div{flex-shrink:0;white-space:nowrap}.brand img{width:13mm;height:auto}.brand div{border-inline-start:.25mm solid #dedfdb;padding-inline-start:3.3mm;line-height:1.35}.brand b{display:block;color:#111;font-weight:500}.brand small{font-size:7pt}
.concept{font-size:7.4pt;color:#74766f}
.foot{position:absolute;bottom:11mm;left:16mm;right:16mm;display:flex;justify-content:space-between;align-items:center;border-top:.25mm solid #dedfdb;padding-top:3mm;font-size:7.3pt;color:#757873}.foot b{color:#111;font-weight:500}.page-no{direction:ltr}
.eyebrow{font-size:8.4pt;font-weight:500;color:#c83020;margin-bottom:3mm}
h2{font-size:24pt;max-width:170mm}.lead{font-size:11.4pt;line-height:1.55;color:#5b5e66;margin-top:4mm;max-width:164mm}.muted{color:#5b5e66}.note{font-size:8.4pt;line-height:1.5;color:#6b6f67;margin-top:5mm}.compact{font-size:8.6pt}.sec+.sec{margin-top:11mm}.sec.small h2{font-size:20pt}.sec.small .lead{font-size:10.3pt;margin-top:3mm}
.rows{display:flex;gap:6mm}.rows>*{flex:1;min-width:0}.number{font-size:7.7pt;color:#c83020;font-weight:500;display:block;margin-bottom:2mm}.rule{height:.25mm;background:#dedfdb;margin:6mm 0}
.bullet-row{padding-top:4mm;border-top:.25mm solid #dedfdb}.bullet-row h3{font-size:12.1pt;margin-bottom:2.5mm}.bullet-row p{font-size:9.1pt;color:#5b5e66}.pill{display:inline-block;border:.25mm solid #d9dcd5;border-radius:1.2mm;padding:1mm 2.5mm;font-size:7.4pt;color:#5f6558}.pill.dark{background:#202120;color:#ddd;border-color:#393b36}.chips{display:flex;flex-wrap:wrap;gap:1.5mm;margin-top:3mm}.chips span{border:.25mm solid #d9dcd5;border-radius:1mm;padding:.7mm 2mm;font-size:7.5pt;color:#52574f}
/* Cover */
.cover .run{margin-bottom:0}.cover-title{margin-top:21mm}.cover-title h1{font-size:46pt;line-height:1.06;letter-spacing:-.025em}.cover-title h1 span{color:#c83020}.cover-title .lead{font-size:13pt;max-width:145mm;margin-top:7mm}.cover-art{height:108mm;margin-top:13mm;background:#121212;border-radius:5mm;position:relative;overflow:hidden;display:flex;justify-content:center;align-items:center}.cover-glow{position:absolute;width:200mm;height:140mm;left:-45mm;top:10mm;background:radial-gradient(ellipse at 35% 75%,#bd301fb3 0,#481f1d80 43%,transparent 70%)}.cover-grid{position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 11.8mm,#ffffff08 11.8mm,#ffffff08 12mm),repeating-linear-gradient(90deg,transparent,transparent 11.8mm,#ffffff08 11.8mm,#ffffff08 12mm)}.art-label{position:absolute;top:6mm;inset-inline-end:7mm;color:#ccc7c2;font-size:8pt}.art-note{position:absolute;bottom:4.5mm;left:0;right:0;text-align:center;color:#baa59d;font-size:7.1pt}.cover-art .member-card{transform:rotate(-5deg);margin-top:-2mm}.cover .note{margin-top:7mm;font-size:8.4pt;max-width:165mm}
/* Membership illustration */
.member-card{position:relative;width:52mm;height:73mm;background:#1b1b1b;border:.25mm solid #3a3734;border-radius:2.7mm;box-shadow:0 5mm 9mm #0003;color:white;flex-shrink:0}.card-top{width:45mm;position:absolute;left:3.5mm;right:auto;top:3mm;display:flex;justify-content:space-between;align-items:start;font-size:4.3pt;line-height:1.5}.card-top{display:block;direction:ltr}.card-top img{width:6.2mm;position:absolute;right:0;top:0}.card-top>div{width:32mm;position:absolute;left:0;top:0}html[dir=rtl] .card-top>div{left:auto;right:0;text-align:right;direction:rtl}html[dir=rtl] .card-top img{right:auto;left:0}.card-top b{font-weight:400}.card-color{width:46mm;position:absolute;top:12.5mm;left:3mm;right:3mm;height:27mm;border-radius:1.4mm}.card-color img{position:absolute;left:0;top:0;width:46mm;height:27mm;border-radius:1.4mm}.card-color strong{position:absolute;top:3mm;inset-inline-start:3.6mm;font-weight:500;font-size:10pt}.card-color span{position:absolute;bottom:2mm;inset-inline-start:3.6mm;font-size:4.3pt;line-height:1.6}.card-color b{display:block;font-size:5.2pt;font-weight:500}.card-qr{position:absolute;left:15.2mm;top:47mm;width:21.7mm;border-radius:1mm;background:white;padding:1.3mm 1.3mm .8mm}.card-qr img{width:100%;display:block}.card-qr small{display:block;color:#111;font-size:2.8pt;direction:ltr;line-height:1.5;text-align:center;letter-spacing:.06em}
/* About */
.about .lead{font-size:13pt;line-height:1.65;max-width:167mm;margin-top:6mm}
.about-stats{margin-top:10mm;padding:9mm 9mm 6mm;background:#131313;color:white;border-radius:4mm}
.about-stat-row{display:table;width:100%;table-layout:fixed}
.about-stat{display:table-cell;width:50%;vertical-align:top;padding:0 7mm}
.about-stat:first-child{padding-inline-start:0}.about-stat:last-child{border-inline-start:.25mm solid #ffffff36}
.about-stat strong{display:block;font-size:46pt;line-height:1.05;font-weight:500;letter-spacing:-.03em;direction:ltr;unicode-bidi:isolate;text-align:start;margin-bottom:4mm}
.about-stat:first-child strong{color:#f34632}html[dir=rtl] .about-stat strong{text-align:right}.about-stat span{display:block;font-size:12pt;color:#e1ded7}
.about-selection{border-top:.25mm solid #ffffff36;margin-top:7mm;padding-top:4mm;font-size:9.2pt;color:#c2c1b9}
.about-source{font-size:7.8pt;color:#74766f;margin-top:3mm}
.about-points{display:table;table-layout:fixed;width:100%;margin-top:14mm;border-top:.25mm solid #dedfdb;padding-top:6mm}
.about-profile{display:table-cell;width:50%;vertical-align:top;padding-inline-end:8mm}
.about-profile:last-child{padding-inline-start:8mm;padding-inline-end:0;border-inline-start:.25mm solid #dedfdb}
.about-profile h3{font-size:14pt;line-height:1.3;margin-bottom:4mm}.about-profile p{font-size:11.1pt;color:#5b5e66;line-height:1.7}
/* Value and showcase */
.value-items{margin-top:7mm}.value-items .bullet-row h3{font-size:11.6pt}.value-items .bullet-row p{font-size:8.8pt}.showcase-head{margin-top:10mm}.showcase-head h3{font-size:16pt}.showcase-head p{font-size:9.7pt;color:#5b5e66;margin-top:3mm;max-width:163mm}.showcase{margin-top:6mm;border:.25mm solid #dedfdb;border-radius:3mm;overflow:hidden}.feature{display:flex;height:58mm;background:#f4f0e7}.feature-info{padding:7mm 7mm 6mm;width:56%;display:flex;flex-direction:column;justify-content:space-between}.feature-info .pill{align-self:start;background:#fff9;border:0;color:#c83020;font-weight:500}.feature-info h3{font-size:20pt;max-width:80mm;margin:4mm 0}.feature-brand{display:flex;align-items:center;gap:2.5mm;font-size:9pt}.feature-brand img{width:7mm;height:7mm}.notebook{width:44%;padding:7mm 7mm 6mm 0;display:flex;align-items:center;justify-content:center;direction:ltr}.notebook-paper{width:58mm;height:43mm;background:#fff;border-radius:1mm;border:.25mm solid #ddd8ce;box-shadow:2mm 3mm 0 #e3ddd2;padding:5mm;transform:rotate(-5deg)}.notebook-paper img{width:10mm;height:10mm;margin-bottom:4mm}.notebook-paper i{display:block;background:#e5e5e0;height:1.2mm;margin:2.8mm 0;border-radius:.5mm}.notebook-paper i:last-child{width:62%}.showcase-small{display:flex;gap:0;border-top:.25mm solid #dedfdb}.showcase-small article{width:50%;display:flex;align-items:center;gap:4mm;padding:5mm;background:white}.showcase-small article+article{border-inline-start:.25mm solid #dedfdb}.showcase-small .brand-tile{width:12mm;height:12mm;padding:2mm;border:.25mm solid #e4e4df;border-radius:2mm;display:flex;align-items:center;justify-content:center;flex-shrink:0}.brand-tile img{width:100%;max-height:8mm}.showcase-small h4{font-size:10.5pt;font-weight:500;margin:0 0 1mm}.showcase-small p{font-size:8.2pt;color:#666}.value .note{font-size:8pt;line-height:1.5}
/* Members and application */
.members-layout{display:flex;gap:9mm;margin-top:6mm;align-items:center}.member-copy{flex:1;min-width:0}.member-group{padding:4mm 0;border-top:.25mm solid #dedfdb}.member-group h3{font-size:12pt;margin-bottom:2mm}.member-group p{font-size:9.4pt;color:#5b5e66}.member-window{width:61mm;flex-shrink:0;border:.25mm solid #dedfdb;border-radius:3mm;overflow:hidden}.window-head{font-size:7.4pt;color:#5b5e66;padding:2.4mm 4mm;border-bottom:.25mm solid #dedfdb}.window-art{background:#f4f4f1;padding:5mm;display:flex;justify-content:center}.window-art .member-card{transform:scale(.72);transform-origin:center;width:52mm;margin:-10mm -8mm}.window-foot{font-size:7.5pt;padding:3mm 4mm;color:#5b5e66}.journey{display:flex;gap:4mm;margin-top:6mm;position:relative}.step{flex:1;min-width:0;border-top:.25mm solid #dedfdb;padding-top:3mm}.step-no{width:7mm;height:7mm;border:.25mm solid #c7cbc1;border-radius:50%;display:block;text-align:center;line-height:6.6mm;font-size:8pt;margin-bottom:3mm}.step:first-child .step-no{background:#111;color:#fff;border-color:#111}.step h3{font-size:10.9pt;margin-bottom:2mm}.step p{font-size:8.6pt;line-height:1.55;color:#5b5e66}.step .pill{font-size:6.8pt;padding:.7mm 1.5mm;margin-top:3mm}.join-section{margin-top:10mm}.join-section h2{font-size:20pt}.join-section .lead{font-size:10.3pt}
/* Partner forms and agreement models */
.membership-page .run{margin-bottom:6mm}
.membership-page .members-layout{margin-top:5mm}
.membership-page .member-group{padding:3mm 0}
.membership-page .member-window{width:53mm}
.membership-page .window-head,.membership-page .window-foot{padding:2mm 3mm}
.membership-page .window-art{height:38mm;padding:2.5mm 0}
.membership-page .window-art .member-card{transform:scale(.45);transform-origin:top center;margin:0}
.join-section{margin-top:7mm}
.join-section .lead{margin-top:2mm}
.join-section .journey{margin-top:5mm;align-items:stretch}
.step{display:flex;flex-direction:column}
.step-heading{display:flex;align-items:flex-start;gap:2mm;min-height:12mm}
.step-heading .step-no{width:5.4mm;height:5.4mm;line-height:5.1mm;flex:none;font-size:7pt;margin:0}
.step-heading h3{flex:1;min-width:0;line-height:1.25;margin:0}
.step-summary{min-height:19mm;margin-bottom:2.5mm}
.partner-model{min-width:0;min-height:48mm;background:#f6f6f3;border:.25mm solid #dedfdb;border-radius:2mm;padding:2.4mm;font-size:7.6pt;line-height:1.38}
.partner-model strong{font-weight:600}
.partner-model dl{margin:0}
.partner-model dt{font-size:7pt;color:#53575d}
.partner-model dd{margin:0;color:#222;font-weight:500;overflow-wrap:anywhere}
.model-field{background:white;border:.25mm solid #e2e3df;border-radius:1mm;padding:1mm 1.3mm;margin-bottom:1mm}
.model-field:last-child{margin-bottom:0}
.model-helper{margin-top:1.5mm;font-size:7pt;color:#53575d}
.model-eyebrow{display:block;font-size:7.1pt;font-weight:600;margin-bottom:1.5mm}
.model-term{padding:1.4mm 1.5mm;margin-top:1.2mm;border-inline-start:.55mm solid #cccfc8;background:#fff}
.model-term.agreed{border-color:#357570;background:#eaf2ef}
.model-pad{display:block;background:white;border:.25mm dashed #a4a69f;border-radius:1mm;padding:6mm 1mm 3.5mm;text-align:center;margin-bottom:2mm;color:#5b5e66}
.model-pad span{display:block;width:80%;margin:auto;padding-bottom:1mm;border-bottom:.25mm solid #dddeda}
.model-link{color:#a3291c;font-weight:600;text-underline-offset:.5mm}
.model-offer{border:.25mm solid #e2e3df;border-radius:1mm;background:#fff;padding:2mm 1.5mm}
.model-offer strong,.model-offer span{display:block;margin-bottom:1mm}
.model-offer strong{font-size:8.5pt;line-height:1.35}
.model-offer span{color:#53575d;font-size:7pt}
.model-offer small{display:block;border-top:.25mm solid #e2e3df;padding-top:1.2mm;font-size:7.2pt}
.join-section .note{margin-top:3mm}
html[dir=rtl] .partner-model{font-size:8.2pt;line-height:1.5}
html[dir=rtl] .model-field dt,html[dir=rtl] .model-helper,html[dir=rtl] .model-offer span,html[dir=rtl] .model-offer small{font-size:7.6pt}
/* Benefits */
.benefit-table{width:100%;border-collapse:collapse;margin-top:7mm;font-size:8.7pt;table-layout:fixed}.benefit-table th,.benefit-table td{border-bottom:.25mm solid #dedfdb;text-align:start;vertical-align:top;padding:3mm 2.5mm}.benefit-table thead th{font-size:10pt;font-weight:600;border-bottom:.4mm solid #111}.benefit-table thead th:first-child,.benefit-table tbody th{width:29mm;font-size:7.8pt;color:#5b5e66;font-weight:500}.benefit-table tbody td{font-size:8.6pt}.benefit-table td b{font-weight:500}.benefit-table small{display:block;font-size:7.7pt;color:#666;margin-top:1.5mm}.option-detail{display:flex;gap:8mm;margin-top:6mm}.option-detail>*{flex:1}.option-detail h3{font-size:10.5pt;margin-bottom:2mm}.option-detail p{font-size:8.7pt;color:#5b5e66}.verify-section{margin-top:11mm}.verify-section h2{font-size:20pt}.verify-section .lead{font-size:10pt}.verify-flow{display:flex;gap:4mm;margin-top:5mm}.verify-flow article{flex:1;min-width:0;border:.25mm solid #dedfdb;border-radius:2.5mm;padding:4mm}.verify-flow article:last-child{background:#eef4f3;border-color:#d2e3df}.verify-flow h3{font-size:10.6pt;margin:2mm 0}.verify-flow p{font-size:8.5pt;color:#5b5e66}.verify-flow .number{margin:0;font-size:7.5pt}.verify-section .note{margin-top:4mm}
/* Reporting */
.dashboard{margin-top:6mm;border:.25mm solid #dedfdb;border-radius:3mm;overflow:hidden}.board-head{display:flex;justify-content:space-between;background:#fafaf8;padding:3mm 4mm;border-bottom:.25mm solid #dedfdb;font-size:8.2pt}.metrics{display:flex}.metric{width:26%;padding:4mm 4mm 5mm;border-inline-end:.25mm solid #dedfdb}.metric strong{font-size:27pt;line-height:1.2;font-weight:500;display:block;margin:2mm 0}.metric span{font-size:7.6pt;color:#5b5e66}.metric small{font-size:6.8pt;line-height:1.45;display:block;color:#73786d}.bar-chart{width:22%;padding:5mm 4mm;display:flex;gap:1.5mm;align-items:flex-end;min-height:32mm}.bar-chart i{flex:1;background:#d3e0da;border-radius:.5mm .5mm 0 0}.bar-chart i:last-child{background:#015e6f}.principles{display:flex;gap:6mm;margin-top:6mm}.principles>*{flex:1;min-width:0}.principles h3{font-size:10.5pt;margin-bottom:2mm}.principles p{font-size:8.6pt;color:#5b5e66}.integration-section{margin-top:12mm}.integration-section h2{font-size:20pt}.integration-section .lead{font-size:10.2pt}.connection{display:flex;gap:8mm;margin-top:6mm;align-items:flex-start}.connection-map{width:48%;border:.25mm solid #dedfdb;border-radius:3mm;padding:7mm 4mm 4mm}.map-row{display:flex;align-items:center;justify-content:center;gap:3mm;text-align:center}.map-node{flex:none;width:29mm;min-width:0}.node-logo{width:12mm;height:12mm;background:#131313;border-radius:3mm;margin:0 auto 2.5mm;display:flex;align-items:center;justify-content:center}.node-logo img{width:8mm}.node-logo.system{background:#f2f2ed;color:#555;font-size:13pt}.map-node b{font-size:9pt;font-weight:500;display:block}.map-node small{font-size:6.8pt;color:#73786d;line-height:1.4;display:block;margin-top:1mm}.map-link{width:8mm;flex-shrink:0;height:.25mm;background:#a6b2a0}.map-functions{border-top:.25mm solid #dedfdb;margin-top:5mm;padding-top:3mm;display:flex;flex-wrap:wrap;gap:1.4mm;justify-content:center}.map-functions span{font-size:7.1pt;background:#f2f2ee;padding:.6mm 1.6mm}.connection-steps{flex:1}.connection-steps article{padding-bottom:4mm;margin-bottom:4mm;border-bottom:.25mm solid #dedfdb}.connection-steps article:last-child{border:0;margin-bottom:0;padding-bottom:0}.connection-steps h3{font-size:10.5pt;margin-bottom:1.2mm}.connection-steps p{font-size:8.8pt;color:#5b5e66}.requirement{margin-top:5mm;background:#f5f5f2;padding:3.5mm 4mm;border-radius:2mm;font-size:8.2pt;color:#5b5e66}.requirement b{font-weight:500;color:#111}
/* Integration scenarios and ending */
.scenario-list{margin-top:7mm}.scenario{padding:4mm 0 4mm;border-top:.25mm solid #dedfdb}.scenario-title{display:flex;gap:3mm;align-items:baseline}.scenario-title .number{margin:0}.scenario-title h3{font-size:13.2pt;flex:1;width:150mm}.scenario p{font-size:9.2pt;line-height:1.55;color:#5b5e66;margin-top:2.5mm;max-width:165mm}.scenario-flow{display:flex;gap:2.2mm;margin-top:4mm}.scenario-flow span{width:25%;background:#f2f2ef;border-radius:1.5mm;min-height:12mm;padding:2.4mm 2.5mm;font-size:7.9pt;line-height:1.45;display:flex;align-items:center}.scenario-flow span:last-child{background:#eaf2ef;color:#215459}.scenario-flow b{font-size:6.8pt;font-weight:500;color:#899182;margin-inline-end:2mm}.closing{background:#131313;color:#fff;border-radius:4mm;padding:7mm 7mm 6mm;margin-top:7mm}.closing h2{font-size:21pt}.closing>p{font-size:9.4pt;color:#c3c2ba;margin-top:2mm}.closing-points{display:flex;gap:5mm;margin-top:5mm}.closing-points span{flex:1;min-width:0;border-top:.25mm solid #ffffff33;padding-top:2.5mm;font-size:9.3pt}.closing-points small{display:block;color:#9c9c92;font-size:6.8pt;margin-bottom:1mm}.closing .site{display:block;color:#d5d2c7;font-size:8pt;margin-top:5mm;text-decoration:none;direction:ltr;text-align:start}
/* Print layout for the two-party diagram. */
.map-row{display:table;width:100%;table-layout:fixed}.map-node{display:table-cell;width:42%;vertical-align:top;text-align:center}.map-link{display:table-cell;width:16%;height:auto;background:transparent;vertical-align:middle}.map-link:after{content:"";display:block;width:100%;height:.25mm;background:#a6b2a0}.node-logo{display:inline-block;padding:2mm;line-height:8mm;margin:0 0 2.5mm;vertical-align:middle}.node-logo img{vertical-align:middle}.node-logo.system{line-height:8mm}html[dir=rtl] .card-color>img{transform:scaleX(-1)}
/* Arabic typography */
html[dir=rtl] body{font-size:10.6pt;line-height:1.65}html[dir=rtl] h1,html[dir=rtl] h2,html[dir=rtl] h3{letter-spacing:0}html[dir=rtl] h2{line-height:1.35}html[dir=rtl] .lead{font-size:12.2pt;line-height:1.75}html[dir=rtl] .cover-title h1{font-size:45pt;line-height:1.2}html[dir=rtl] .cover-title .lead{font-size:13.5pt}html[dir=rtl] .cover-title{margin-top:15mm}html[dir=rtl] .cover-art{height:105mm;margin-top:10mm}html[dir=rtl] .about .lead{font-size:13.5pt}html[dir=rtl] .eyebrow{font-size:9pt}html[dir=rtl] .bullet-row p{font-size:10pt}html[dir=rtl] .value-items .bullet-row p{font-size:9.3pt}html[dir=rtl] .value-items .bullet-row h3{font-size:12pt}html[dir=rtl] .showcase-head p{font-size:10.5pt}html[dir=rtl] .feature-info h3{font-size:21pt;line-height:1.4}html[dir=rtl] .notebook{padding:7mm 0 6mm 7mm}html[dir=rtl] .step p{font-size:9.1pt}html[dir=rtl] .benefit-table tbody td{font-size:9.1pt}html[dir=rtl] .benefit-table thead th{font-size:10.2pt}html[dir=rtl] .benefit-table tbody th{font-size:8.4pt}html[dir=rtl] .verify-flow p{font-size:9.1pt}html[dir=rtl] .principles p{font-size:9.3pt}html[dir=rtl] .connection-steps p{font-size:9.4pt}html[dir=rtl] .requirement{font-size:8.8pt}html[dir=rtl] .scenario p{font-size:10pt}html[dir=rtl] .scenario-flow span{font-size:8.8pt}html[dir=rtl] .note{font-size:9pt}html[dir=rtl] .concept{font-size:8pt}html[dir=rtl] .foot{font-size:8pt}
/* Compact API reference page: explanatory copy with small faithful excerpts. */
.api-page .run{margin-bottom:6mm}.api-page h2{font-size:22pt}.api-page .lead{font-size:10pt;line-height:1.5;margin-top:3mm}
.api-base{margin-top:4mm;font-size:8pt;color:#5b5e66}.api-base code{display:inline-block;margin:0 3mm;direction:ltr;text-align:left;color:#111;font-family:monospace;font-size:8pt;margin-top:0}
.api-list{margin-top:4mm}.api-scenario{padding:2.5mm 0;border-top:.25mm solid #dedfdb}
.api-heading{display:table;width:100%;table-layout:fixed}.api-heading h3{display:table-cell;width:55%;font-size:12pt;line-height:1.3}.api-heading .direction{display:table-cell;width:45%;text-align:end;font-size:8pt;color:#5b5e66;vertical-align:middle}
.api-body{font-size:9pt;line-height:1.5;color:#5b5e66;margin-top:2mm}
.code-pair{display:table;width:100%;table-layout:fixed;direction:ltr;border-spacing:0;margin-top:3mm}
.code-col{display:table-cell;width:59%;background:#f5f5f2;padding:2mm 3mm 1.5mm;vertical-align:top;border-radius:1.5mm 0 0 1.5mm}.code-col:last-child{width:41%;background:#edf4f1;border-radius:0 1.5mm 1.5mm 0}
.code-label{font-size:7.4pt;font-weight:500;color:#5b5e66;margin-bottom:1.5mm}
.code-col pre{font-family:monospace;font-size:7.1pt;line-height:1.4;margin:0;white-space:pre-wrap;overflow-wrap:anywhere;direction:ltr;text-align:left;color:#111}
.api-close{display:table;width:100%;background:#131313;color:#fff;border-radius:3mm;padding:4mm 5mm;margin-top:3mm}.api-close h2{display:table-cell;width:42%;font-size:14pt;vertical-align:middle;line-height:1.35}.api-close p{display:table-cell;width:58%;font-size:9pt;vertical-align:middle;color:#d1cec7;line-height:1.6}.api-outcome{font-size:8pt;line-height:1.45;color:#3f5f56;margin-top:2mm}.api-detail{font-size:8.3pt;line-height:1.5;color:#5b5e66;margin-top:2.5mm}
.api-page .note{font-size:7.8pt;line-height:1.5;margin-top:2mm}.api-page .closing{padding:4mm 5mm;margin-top:4mm;border-radius:3mm}.api-page .closing h2{font-size:15pt;line-height:1.3}.api-page .closing>p{font-size:8pt;margin-top:0}.api-page .closing-points{margin-top:3mm;gap:4mm}.api-page .closing-points span{font-size:8.3pt;padding-top:2mm}.api-page .closing-points small{display:none}.api-page .closing .site{display:none}
.monitoring .integration-section{margin-top:9mm}.monitoring .integration-section h2{font-size:19pt}.monitoring .integration-section .lead{font-size:9.9pt;line-height:1.5}.monitoring .connection{margin-top:5mm;gap:6mm}.monitoring .connection-steps h3{font-size:10pt}.monitoring .connection-steps p{font-size:8.7pt;line-height:1.5}.monitoring .connection-steps article{padding-bottom:3mm;margin-bottom:3mm}.monitoring .requirement{font-size:8.1pt;line-height:1.5;margin-top:4mm}
html[dir=rtl] .api-page .lead{font-size:10.7pt;line-height:1.6}html[dir=rtl] .api-body{font-size:9.5pt;line-height:1.6}html[dir=rtl] .api-heading .direction{font-size:8.5pt}html[dir=rtl] .api-detail{font-size:8.8pt;line-height:1.6}html[dir=rtl] .api-outcome{font-size:8.8pt;line-height:1.6}html[dir=rtl] .api-page .note{font-size:8.2pt}html[dir=rtl] .monitoring .integration-section .lead{font-size:10.5pt;line-height:1.6}html[dir=rtl] .monitoring .connection-steps p{font-size:9.2pt;line-height:1.6}html[dir=rtl] .monitoring .requirement{font-size:8.6pt;line-height:1.6}
/* Business-facing integration flows, with an optional technical reference. */
.operation-list{margin-top:6mm}.operation{padding:4mm 0;border-top:.25mm solid #dedfdb}
.operation .api-heading h3{font-size:13.5pt;width:56%}.operation .api-heading .direction{width:44%;font-size:7.8pt;line-height:1.4}
.operation-body{font-size:10pt;line-height:1.55;color:#5b5e66;margin-top:2.5mm;max-width:170mm}
.operation-steps{display:table;width:100%;table-layout:fixed;margin-top:3mm;background:#f4f4f0;border-radius:2mm}
.operation-steps>div{display:table-cell;width:33.333%;padding:3mm 3mm;vertical-align:top;border-inline-end:.25mm solid #e1e3db}.operation-steps>div:last-child{border:0}
.operation-steps span{display:block;font-size:6.8pt;color:#858a7d;line-height:1.2;margin-bottom:1.5mm}
.operation-steps b{display:block;font-size:9.2pt;line-height:1.4;font-weight:500}
.operation-summary{font-size:9pt;line-height:1.5;color:#3c5c54;margin-top:2.5mm}
.operation-reference{display:block;direction:ltr;text-align:left;font-size:7.3pt;font-family:monospace;color:#777c74;line-height:1.4;margin-top:2mm}
.api-page .operation-note{font-size:8.1pt;margin-top:2mm}
.technical-link{display:block;font-size:8.2pt;line-height:1.5;color:#075f6c;text-decoration:underline;margin-top:2.5mm;max-width:175mm}
.api-page .api-close{margin-top:4mm}
html[dir=rtl] .operation-body{font-size:10.7pt;line-height:1.65}html[dir=rtl] .operation .api-heading .direction{font-size:8.7pt}html[dir=rtl] .operation-steps b{font-size:10pt;line-height:1.5}html[dir=rtl] .operation-summary{font-size:9.5pt;line-height:1.6}html[dir=rtl] .technical-link{font-size:9.2pt}html[dir=rtl] .api-page .operation-note{font-size:8.8pt}

'''

def build(data):
    ar=data['lang']=='ar'
    tr=lambda arabic,english:arabic if ar else english
    ui=data['ui']
    sections=[]
    def page(index,label,body,cls=''):
        head=f'<div class="run"><div class="brand">{img("jaree.svg",alt="Jaree")}<div><b>{e(ui["club"])}</b><small>{e(ui["partners"])}</small></div></div><span class="concept">{e(ui["concept"])}</span></div>'
        foot=f'<footer class="foot"><span><b>{e(ui["club"])}</b> · {e(label)}</span><span class="page-no">{index:02d} / {PAGE_COUNT:02d}</span></footer>'
        sections.append(f'<section class="page {cls}">{head}<main>{body}</main>{foot}</section>')
    def heading(number,label,title,lead,cls=''):
        return f'<div class="sec {cls}"><p class="eyebrow">{number:02d} / {e(label)}</p><h2>{e(title)}</h2><p class="lead">{e(lead)}</p></div>'
    def card():
        return f'<div class="member-card"><div class="card-top"><div>{e(ui["memberOf"])}<br><b>{e(ui["club"])}</b></div>{img("jaree-white.svg")}</div><div class="card-color">{img("red-art.png")}<strong>{e(ui["memberName"])}</strong><span>{e(ui["membership"])}<b>{e(ui["investor"])}</b></span></div><div class="card-qr">{img("qr.svg")}<small>DEMO · JAREE CLUB</small></div></div>'
    def bullets(items):
        return ''.join(f'<article class="bullet-row"><span class="number">{i+1:02d}</span><h3>{e(x[0])}</h3><p>{e(x[1])}</p></article>' for i,x in enumerate(items))

    intro=data['intro']
    body=f'<div class="cover-title"><p class="eyebrow">{e(intro["eyebrow"])}</p><h1>{e(intro["heading"][0])}<br><span>{e(intro["heading"][1])}</span></h1><p class="lead">{e(intro["lead"])}</p></div><div class="cover-art"><div class="cover-glow"></div><div class="cover-grid"></div><span class="art-label">{e(ui["club"])}</span>{card()}<span class="art-note">{e(ui["example"])}</span></div><p class="note">{e(intro["note"])}</p>'
    page(1,tr('تجربة الشريك','The partner experience'),body,'cover')

    a=data['about']
    body=heading(2,tr('عن جريء','About Jaree'),a['title'],a['lead'])
    body+='<div class="about-stats"><div class="about-stat-row">'+''.join(f'<div class="about-stat"><strong>{e(x[0])}</strong><span>{e(x[1])}</span></div>' for x in a['stats'])+f'</div><p class="about-selection">{e(a["selection"])}</p></div><p class="about-source">{e(a["source"])}</p>'
    body+='<div class="about-points">'+''.join(f'<article class="about-profile"><h3>{e(x[0])}</h3><p>{e(x[1])}</p></article>' for x in a['items'])+'</div>'
    page(2,tr('عن جريء','About Jaree'),body,'about')

    v=data['value'];s=v['showcase']
    body=heading(3,tr('قيمة الشراكة','Partner value'),v['title'],v['lead'])
    body+=f'<div class="rows value-items">{bullets(v["items"])}</div><div class="showcase-head"><h3>{e(s["title"])}</h3><p>{e(s["body"])}</p></div>'
    body+=f'<div class="showcase"><div class="feature"><div class="feature-info"><span class="pill">{e(s["featured"])}</span><h3>{e(s["notion"])}</h3><div class="feature-brand">{img("notion.svg")}<bdi>Notion</bdi></div></div><div class="notebook"><div class="notebook-paper">{img("notion.svg")}<i></i><i></i><i></i></div></div></div><div class="showcase-small">'
    for brand in ['regus','hilton']:
        body+=f'<article><div class="brand-tile">{img(brand+".svg")}</div><div><h4>{e(s[brand])}</h4><p><bdi>{brand.capitalize()}</bdi></p></div></article>'
    body+=f'</div></div><p class="note">{e(ui["brandNote"])}</p>'
    page(3,tr('قيمة الشراكة','Partner value'),body,'value')

    m=data['members'];j=data['join']
    body=heading(4,tr('العضوية','Membership'),m['title'],m['lead'])
    body+='<div class="members-layout"><div class="member-copy">'+''.join(f'<article class="member-group"><h3>{e(x[0])}</h3><p>{e(x[1])}</p></article>' for x in m['groups'])+f'<p class="note">{e(m["foot"])}</p></div><div class="member-window"><div class="window-head">{e(m["window"])}</div><div class="window-art">{card()}</div><div class="window-foot">{e(m["body"])}</div></div></div>'
    examples = j['examples']
    application = examples['application']
    terms = examples['terms']
    signing = examples['signing']
    benefit = examples['benefit']
    demo_url = f'{PUBLIC_SITE}{tr("index.html","en.html")}?step=2&stage=2#join'
    demo_label = tr('جرّب التوقيع في العرض','Try signing in the presentation')
    fields = ''.join(
        f'<div class="model-field"><dt>{e(label)}</dt><dd>{e(value)}</dd></div>'
        for label, value in application['fields']
    )
    help_label = application.get('help', tr('ساعدني في التعبئة','Help me fill this'))
    models = [
        f'<dl>{fields}</dl><div class="model-helper">{e(help_label)}</div>',
        f'<strong class="model-eyebrow">{e(terms["clause"])}</strong>'
        f'<dl><div class="model-term"><dt>{e(terms["before"])}</dt><dd>{e(terms["old"])}</dd></div>'
        f'<div class="model-term agreed"><dt>{e(terms["after"])}</dt><dd>{e(terms["new"])}</dd></div></dl>',
        f'<strong class="model-eyebrow">{e(signing["pad"])}</strong>'
        f'<div class="model-pad"><span>{e(signing["placeholder"])}</span></div>'
        f'<a class="model-link" href="{e(demo_url)}">{e(demo_label)}</a>',
        f'<strong class="model-eyebrow">{e(benefit["title"])}</strong>'
        f'<div class="model-offer"><span>{e(benefit["brand"])}</span>'
        f'<strong>{e(benefit["offer"])}</strong><span>{e(benefit["details"])}</span>'
        f'<small>{e(benefit["action"])}</small></div>',
    ]
    body+=f'<section class="join-section">{heading(5,tr("الانضمام والإطلاق","Application and launch"),j["title"],j["lead"])}<div class="journey">'
    for index, (stage, model) in enumerate(zip(j['stages'], models)):
        body += (
            '<article class="step">'
            f'<div class="step-heading"><span class="step-no">{index+1}</span><h3>{e(stage["name"])}</h3></div>'
            f'<p class="step-summary">{e(j["handout"][index])}</p>'
            f'<div class="partner-model">{model}</div></article>'
        )
    body+=f'</div><p class="note">{e(j["foot"])}</p></section>'
    page(4,tr('العضوية والانضمام','Membership and joining'),body,'membership-page')

    b=data['benefit'];t=data['trust']
    body=heading(6,tr('طرق الاستفادة','Redemption options'),b['title'],b['lead'])
    body+='<table class="benefit-table"><thead><tr><th></th>'+''.join(f'<th>{e(x)}</th>' for x in b['tabs'])+'</tr></thead><tbody>'
    rows=[(tr('المثال','Example'),[f'<bdi>{e(x["brand"])}</bdi><small>{e(x["title"])}</small>' for x in b['methods']]),(tr('ما يقدّمه العضو','The member presents'),[e(x['method']) for x in b['methods']]),(tr('مكان التحقّق','Where it is checked'),[e(x['place'])+(f'<small>{e(tr("عند تفعيل الربط","If integration is enabled"))}</small>' if i==0 else '') for i,x in enumerate(b['methods'])]),(b['limit'],[e(x['unit']) for x in b['methods']])]
    for label,cells in rows:
        body+=f'<tr><th>{e(label)}</th>'+''.join(f'<td>{x}</td>' for x in cells)+'</tr>'
    body+='</tbody></table>'
    body+=f'<div class="option-detail"><div><h3>{e(b["codeTitle"])}</h3><p>{e(b["codeBody"])}</p></div><div><h3>{e(b["controls"])}</h3><div class="chips">'+''.join(f'<span>{e(x)}</span>' for x in b['controlLabels'])+'</div></div></div>'
    body+=f'<p class="note compact">{e(ui["brandNote"])}</p><section class="verify-section">{heading(7,tr("التحقّق والتأكيد","Verification and confirmation"),t["title"],t["lead"])}<div class="verify-flow">'
    flow=[(tr('التحقّق من الأهلية','Check eligibility'),t['initial']),(t['confirm'],t['result']),(t['repeated'],t['repeatNote'])]
    for i,(title,copy) in enumerate(flow):
        body+=f'<article><span class="number">{i+1:02d}</span><h3>{e(title)}</h3><p>{e(copy)}</p></article>'
    body+=f'</div><p class="note">{e(t["note"])}</p></section>'
    page(5,tr('الاستفادة والتحقّق','Redemption and verification'),body)

    n=data['insights'];c=data['connect']
    body=heading(8,tr('المتابعة والتحكّم','Monitoring and control'),n['title'],tr('تُقاس المشاهدات والرموز الصادرة والاستفادات المؤكدة كلٌّ على حدة.','Track views, codes issued and confirmed redemptions separately.'))
    body+=f'<div class="dashboard"><div class="board-head"><b>{e(n["dashboard"])}</b><span>{e(ui["figures"])}</span></div><div class="metrics">'
    for number,x in zip([48,24,72],n['metrics']):
        body+=f'<div class="metric"><span>{e(x[0])}</span><strong>{number}</strong><small>{e(x[1])}</small></div>'
    body+='<div class="bar-chart">'+''.join(f'<i style="height:{x}mm"></i>' for x in [6,9,12,9,15,21])+'</div></div></div><div class="principles">'+''.join(f'<article><h3>{e(x[0])}</h3><p>{e(x[1])}</p></article>' for x in n['principles'])+'</div>'
    body+=f'<section class="integration-section">{heading(9,tr("الربط التقني","Integration"),c["title"],c["lead"])}<div class="connection"><div class="connection-map"><div class="map-row"><div class="map-node"><div class="node-logo system">&lt;/&gt;</div><b>{e(c["system"])}</b><small>{e(c["systemNote"])}</small></div><div class="map-link"></div><div class="map-node"><div class="node-logo">{img("jaree-white.svg")}</div><b>{e(ui["club"])}</b><small>{e(c["clubNote"])}</small></div></div><div class="map-functions">'+''.join(f'<span>{e(x)}</span>' for x in c['functions'])+'</div></div><div class="connection-steps">'+''.join(f'<article><h3>{e(x[0])}</h3><p>{e(x[1])}</p></article>' for x in c['steps'])+'</div></div>'
    body+=f'<div class="requirement"><b>{e(c["detailTitle"])}.</b> {e(c["detail"])}</div></section>'
    page(6,tr('المتابعة والربط','Monitoring and integration'),body,'monitoring')

    s=data['scenarios']
    body=heading(10,tr('عمليات الربط','Integration operations'),s['title'],s['lead'])
    references={'verify':'POST /codes/check','confirm':'POST /uses · Idempotency-Key','issue':'HTTPS · HMAC-SHA256'}
    body+='<div class="operation-list">'
    for i,x in enumerate(s['items']):
        body+=f'<article class="operation"><div class="api-heading"><h3>{e(x["title"])}</h3><span class="direction">{e(x["direction"])}</span></div><p class="operation-body">{e(x["body"])}</p><div class="operation-steps">'
        for k,step in enumerate(x['steps']):
            body+=f'<div><span>{k+1:02d}</span><b>{e(step)}</b></div>'
        body+=f'</div><p class="operation-summary">{e(x["summary"])}</p><code class="operation-reference">{e(references[x["id"]])}</code></article>'
    body+=f'</div><p class="note operation-note">{e(s["note"])}</p><a class="technical-link" href="https://nfatjaree.github.io/jaree-club-presentation/partners-v2/#scenarios">{e(s["pdfTechnicalLabel"])}</a><section class="api-close"><h2>{e(c["closing"])}</h2><p>'+e(' · '.join(c['closingLabels']))+'</p></section>'
    page(7,tr('عمليات الربط والخطوة التالية','Integration operations and next step'),body,'api-page')

    return f'<!doctype html><html lang="{e(data["lang"])}" dir="{e(data["dir"])}"><head><meta charset="utf-8"><title>{e(ui["club"])} | {e(ui["partners"])}</title><style>{CSS}</style></head><body>'+''.join(sections)+'</body></html>'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--lang',choices=['ar','en','both'],default='both');args=parser.parse_args()
    setup_assets()
    evidence={}
    for lang in (['ar','en'] if args.lang=='both' else [args.lang]):
        data=json.loads((SOURCE/'content'/f'{lang}.json').read_text())
        text=build(data)
        html=OUTPUT/f'jaree-club-partners-{lang}.html';html.write_text(text)
        pdf=OUTPUT/f'Jaree-Club-Partners-{lang.upper()}.pdf'
        doc=HTML(filename=str(html)).render()
        if len(doc.pages)!=PAGE_COUNT:raise RuntimeError(f'{lang}: expected {PAGE_COUNT} pages, got {len(doc.pages)}')
        def walk(box):
            yield box
            for child in getattr(box, 'children', []):
                yield from walk(child)
        clearances=[]
        for number, rendered_page in enumerate(doc.pages, 1):
            boxes=list(walk(rendered_page._page_box))
            main_box=next(box for box in boxes if box.element_tag=='main')
            footer_box=next(box for box in boxes if box.element_tag=='footer')
            gap=footer_box.position_y-(main_box.position_y+main_box.height)
            if gap < 12: raise RuntimeError(f'{lang} page {number}: content reaches footer')
            clearances.append(round(gap/3.77952756,2))
        doc.write_pdf(str(pdf))
        evidence[lang]={'pages':len(doc.pages),'bytes':pdf.stat().st_size,'footer_clearance_mm':clearances,'file':pdf.name}
        print(f'{lang}: {len(doc.pages)} pages, {pdf.stat().st_size} bytes -> {pdf}')
    print(json.dumps(evidence, indent=2))

if __name__=='__main__':
    main()
