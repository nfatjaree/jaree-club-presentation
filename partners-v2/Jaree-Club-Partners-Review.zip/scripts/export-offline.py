"""Export the two-language presentation and its review source bundle."""
from pathlib import Path
import base64
import json
import mimetypes
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / 'dist'
OUT = ROOT / 'deliverables'
OFFLINE = OUT / 'offline'
OFFLINE.mkdir(parents=True, exist_ok=True)


def data_url(path):
    mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode()


def inline_css(path):
    return re.sub(r'url\([\'\"]?([^\)\'\"]+)[\'\"]?\)',
                  lambda m: 'url("' + data_url(path.parent / m[1]) + '")',
                  path.read_text())


logos = {name: data_url(DIST / f'assets/{name}.svg')
         for name in ('notion', 'regus', 'hilton')}
script = (DIST / 'app.js').read_text().replace(
    '`assets/${method.brand.toLowerCase()}.svg`',
    '(' + json.dumps(logos) + ')[method.brand.toLowerCase()]')

for filename in ('index.html', 'en.html'):
    html = (DIST / filename).read_text()
    for stylesheet in ('assets/fonts.css', 'style.css'):
        html = html.replace(f'<link rel="stylesheet" href="{stylesheet}">',
                            '<style>' + inline_css(DIST / stylesheet) + '</style>')
    html = re.sub(r'(src|href)="(assets/[^\"]+)"',
                  lambda m: m[1] + '="' + data_url(DIST / m[2]) + '"', html)
    html = html.replace('<script src="app.js" defer></script>', '')
    html = html.replace('</body>', '<script>' + script + '</script></body>')
    (OFFLINE / filename).write_text(html)

with zipfile.ZipFile(OUT / 'Jaree-Club-Partners-Offline.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for filename in ('index.html', 'en.html'):
        archive.write(OFFLINE / filename, filename)
    archive.write(DIST / 'assets/FONT-LICENSE.txt', 'FONT-LICENSE.txt')
    for pdf in sorted(DIST.glob('*.pdf')):
        archive.write(pdf,pdf.name)
        (OFFLINE / pdf.name).write_bytes(pdf.read_bytes())

for locale in ('ar', 'en'):
    data = json.loads((ROOT / f'content/{locale}.json').read_text())
    lines = [f"# {data['title']}", '', 'Editable source: `content/' + locale + '.json`', '']

    def walk(value, key):
        if isinstance(value, dict):
            for child, item in value.items():
                walk(item, f'{key}.{child}' if key else child)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                walk(item, f'{key}[{index}]')
        else:
            lines.extend([f'**{key}**', '', str(value), ''])

    walk(data, '')
    (ROOT / f'COPY_{locale.upper()}.md').write_text('\n'.join(lines))

with zipfile.ZipFile(OUT / 'Jaree-Club-Partners-Review.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for folder in ('dist', 'content', 'src', 'pdf'):
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_file() and 'renders' not in path.parts and path.suffix.lower() not in ('.log',):
                archive.write(path, path.relative_to(ROOT))
    for filename in ('README.md', 'REVIEW_BRIEF.md', 'COPY_AR.md', 'COPY_EN.md',
                     'scripts/build.py', 'scripts/export-offline.py', 'scripts/build-partner-pdf.py', 'scripts/requirements-pdf.txt'):
        archive.write(ROOT / filename, filename)

print('Created bilingual offline export, complete copy files and review source bundle.')
