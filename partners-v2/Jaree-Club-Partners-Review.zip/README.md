# Jaree Club — Partner presentation

Arabic and English interactive presentation for prospective partners. A developing concept, not a product acceptance report or an announcement of commercial partnerships.

## Open

- Arabic: https://nfatjaree.github.io/jaree-club-presentation/partners-v2/
- English: https://nfatjaree.github.io/jaree-club-presentation/partners-v2/en.html

This is the second version. The first stays unchanged at `/partners/`.

The public presentation requires no account. It has no analytics, forms, application API calls or external runtime dependencies.

## Edit and build

1. Edit the product copy in `content/ar.json` and `content/en.json`.
2. Edit interactions in `src/app.js`, styles in `src/style.css` and page structure in `scripts/build.py`.
3. Run `python3 scripts/build.py`.
4. Run `python3 -m http.server 3339 --bind 127.0.0.1 --directory dist` and open the local page.
5. Run `python3 scripts/export-offline.py` to regenerate copy documents, the offline ZIP and the complete review bundle.

The website build uses only Python’s standard library; the PDF build uses WeasyPrint. `dist/` is the generated public site. Keep the two offline HTML files in the same directory so language switching works.

## Structure

Ten sections: overview, About Jaree, partner value, membership, application and launch, redemption options, verification, reporting, integration and practical integration scenarios. Notion, Regus and Hilton are labelled illustrative examples. Selecting an example carries it into verification and reporting, where the example names where its check happens (the partner's system, or Jaree's verification page). Confirmation adds one illustrative use; repeating it does not add another. Language switching preserves the selection, verification stage and current section.

## Boundaries

- Membership and benefit rules define eligibility; a shared code alone does not prevent forwarding.
- Code allocation or display is distinct from a confirmed redemption.
- Reporting omits member names; authorised verification may require scoped data.
- Integration is optional and needs preparation and testing against the partner's actual system.
- Membership artwork, operational examples, dashboard figures and simulated actions are illustrative. The About Jaree figures (180 investors admitted; more than 1,000 investor applications) come from the supplied partnership deck; they are not live counters.

## Assets

The supplied visual reference is https://nfatjaree.github.io/jaree-club-presentation/ . Jaree logos, demonstration card artwork and illustrative brand logos are retained from that reference. IBM Plex Sans Arabic fonts and their licence are bundled in `dist/assets/`. No new commercial partnership or brand endorsement is implied.

## PDFs

Arabic and English editions contain seven pages each. The introduction, partner-display example and three integration operations use the same content source as the website. The PDF explains each operation briefly and links to the optional API request/response examples in the interactive presentation. Install `scripts/requirements-pdf.txt` in a virtual environment, then run `python scripts/build-partner-pdf.py` to rebuild the print editions. The pinned libraries are WeasyPrint 70.0 and CairoSVG 2.9.1; on macOS, set `DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib` if needed for the installed rendering libraries. The PDFs are named `Jaree-Club-Partners-AR.pdf` and `Jaree-Club-Partners-EN.pdf`.

## Verification

The November 2026 refinement was checked in the in-app browser at desktop and 390px/360px phone widths: navigation, new introduction, brand-example links, integration tabs, language context, confirmation without double counting, motion control, assets and horizontal overflow. The PDFs were rendered for visual review in both languages. JavaScript syntax and static links were checked. These are presentation checks, not application acceptance; physical devices and separate Safari/Firefox sessions were not checked.

The original root presentation, the first `/partners/` version and all Jaree application environments are unchanged.
