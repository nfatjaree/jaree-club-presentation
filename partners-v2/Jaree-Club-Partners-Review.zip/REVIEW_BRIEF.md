# Partner presentation — review brief

## Objective

Review and refine this public bilingual presentation for prospective Jaree Club partners. Keep it formal, concise and visually consistent with Jaree. It explains a developing concept from application through publication, redemption, reporting and optional integration. It must not imply a finished product, guaranteed prevention of code sharing, real commercial offers or existing partnerships with the example brands.

## Files

- `content/ar.json`, `content/en.json`: authoritative editable copy.
- `COPY_AR.md`, `COPY_EN.md`: complete readable copy with matching source keys.
- `src/app.js`, `src/style.css`, `src/icons.svg`: interactions, styles and icons.
- `scripts/build.py`: shared HTML structure and generation.
- `dist/`: complete generated presentation, fonts and assets.
- `scripts/export-offline.py`: regenerates the offline and source bundles.

## What changed in this refinement

A concise introduction explains Jaree before the Club proposition. The official monochrome logo replaces the modified two-colour mark. The header groups language and contents controls; motion and PDF access are in the contents menu. The redundant section-bottom navigation has been removed, while the footer arrows, functional example links and native scrolling remain.

The existing value section shows an illustrative featured Notion benefit and compact Regus/Hilton examples. Three selectable technical examples follow the integration section: eligibility checks, idempotent redemption confirmation and signed on-demand code issuance. Actual API paths, authentication headers and response excerpts make the direction of each request clear. Existing-code upload remains explained as an alternative. They distinguish code allocation from confirmed use and do not promise named connectors. Arabic and English PDFs include the same additions.

## Review scope

1. Arabic and English clarity, terminology and equivalence; remove repetition without removing meaningful eligibility or concept qualifications.
2. Typography, spacing, RTL/LTR, contrast and hierarchy on desktop and phone.
3. End-to-end example: choose a method, verify, confirm, see activity, repeat, reset and switch languages.
4. Clear separation between code display/allocation, eligibility checks and confirmed redemption.
5. Optional integration explained simply, without promising named connectors or production readiness.

Make changes in the source and rebuild; do not edit only generated HTML. Preserve the original presentation at the repository root and the first version at `/partners/`; publish refinements only to `/partners-v2/`. This assignment does not authorise changes to Jaree app code, Test, Production, permissions, authentication or deployment schedules.

Return focused findings and a revised local preview for joint review. Do not republish a revised version until it is approved. Use a specialist review only for a concrete uncertainty that cannot be resolved directly; avoid repeated broad audits.

## Evidence and limits

Source, matching copy structure, generated assets/anchors and JavaScript syntax checked. Browser checks cover Arabic/English desktop and 390px layouts, application-stage panels, the three example methods, verification and one-time confirmation, reporting, motion controls and retained language context. No physical-device Safari/Firefox test. Offline resources are embedded and statically verified; direct file execution is unverified. This evidence concerns the presentation only.

## Partner-value clarification

The owner requested explicit value for partners: access to a trusted investor community including high-net-worth individuals, website visibility, and featured placement for distinctive benefits. The supplied partnership deck supports 180 admitted investors, more than 1,000 applications, accredited-investor status and proven financial standing. The About section cites that source; these are not live counts or independently audited statistics. Copy does not guarantee sales or automatic featured placement. Featured placement is part of the developing concept, not a statement that its product implementation is complete.

## Final API precision review

Eligibility checks are preliminary: the example includes benefit availability and the permitted confirmation route, not only code validity. Grant the benefit only after successful confirmation. A successful replay includes `status: CONFIRMED`; retry the same request with the same key. Cross-route order-reference deduplication is scoped to the same member and benefit. Testing follows the benefit route; check-only access does not require confirmation. Signed issuance retries retain their request ID, and the partner must return the original code.

These examples were checked against the implemented routes and recorded Test exercises with the reference system. They are introductory excerpts, not a complete integration guide, a fresh Test acceptance run, proof of named commerce connectors or Production readiness.
