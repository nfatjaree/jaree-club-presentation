# نادي جريء | تجربة الشريك

Editable source: `content/ar.json`

**lang**

ar

**dir**

rtl

**title**

نادي جريء | تجربة الشريك

**description**

تعرّفوا على رحلة الشريك في نادي جريء: الانضمام، وطرح المزايا، والاستفادة، والمتابعة، والربط.

**ui.club**

نادي جريء

**ui.partners**

للشركاء

**ui.concept**

تصوّر أوّلي

**ui.menu**

أقسام العرض

**ui.skip**

انتقل إلى المحتوى

**ui.pause**

إيقاف الحركة

**ui.play**

تشغيل الحركة

**ui.fullscreen**

ملء الشاشة

**ui.exitFullscreen**

الخروج من ملء الشاشة

**ui.previous**

القسم السابق

**ui.next**

القسم التالي

**ui.home**

بداية العرض

**ui.language**

English

**ui.alternate**

en.html

**ui.nextLabel**

التالي

**ui.backTop**

العودة إلى البداية

**ui.example**

مثال توضيحي

**ui.figures**

أرقام توضيحية

**ui.brandNote**

أمثلة توضيحية؛ لا تمثّل شراكات أو عروضًا فعلية من العلامات المعروضة.

**ui.continue**

متابعة التجربة

**ui.memberName**

اسم العضو

**ui.memberOf**

عضو في

**ui.membership**

العضوية

**ui.investor**

مستثمر

**ui.startup**

شركة ناشئة

**nav[0]**

التعريف

**nav[1]**

قيمة الشراكة

**nav[2]**

العضوية

**nav[3]**

الانضمام والنشر

**nav[4]**

طرق الاستفادة

**nav[5]**

التحقّق

**nav[6]**

المتابعة

**nav[7]**

الربط

**intro.eyebrow**

تجربة الشريك

**intro.heading[0]**

نادي جريء

**intro.heading[1]**

للشركاء

**intro.lead**

قدّموا مزايا للمستثمرين والشركات الناشئة، مع إدارة واضحة للنشر والاستفادة والمتابعة.

**intro.action**

اكتشفوا قيمة الشراكة

**intro.note**

تصوّر قيد التطوير. الواجهات والأمثلة والأرقام توضيحية.

**intro.float1[0]**

اشتراك رقمي

**intro.float1[1]**

رمز مخصّص للعضو

**intro.float2[0]**

مساحة عمل

**intro.float2[1]**

التحقّق ببطاقة العضوية

**members.title**

العضوية والفئات المستفيدة

**members.lead**

ترتبط العضوية بحساب معتمد في جريء. يحدّد الشريك جمهور كل ميزة: المستثمرون، أو الشركات الناشئة، أو كلاهما.

**members.groups[0][0]**

الشركات الناشئة

**members.groups[0][1]**

عضوية يحملها ممثّل الشركة، ومزايا تدعم احتياجات العمل.

**members.groups[1][0]**

المستثمرون

**members.groups[1][1]**

مزايا وخدمات وتجارب تناسب أعمالهم واهتماماتهم.

**members.window**

حساب العضو

**members.heading**

بطاقة العضوية والمزايا

**members.body**

يجد العضو بطاقته، والمزايا المتاحة له، وشروط الاستفادة في حسابه.

**members.foot**

التحقّق من البطاقة لا يسجّل استفادة تلقائيًا.

**members.next**

الانضمام وإطلاق المزايا

**join.title**

من طلب الشراكة إلى النشر

**join.lead**

بعد قبول الشراكة، تُرسل بيانات الصفحة والمزايا الأولى في طلب إطلاق واحد.

**join.stages[0].name**

تقديم الطلب

**join.stages[0].summary**

بيانات الجهة ووسيلة التواصل

**join.stages[0].title**

تعريف بالجهة

**join.stages[0].body**

اسم الجهة ونشاطها وبيانات التواصل، ورابط موقعها إن وُجد. يُحفظ الطلب أثناء الإعداد.

**join.stages[0].status**

مسودة

**join.stages[0].rows[0]**

بيانات الجهة

**join.stages[0].rows[1]**

النشاط والرابط

**join.stages[0].rows[2]**

وسيلة التواصل

**join.stages[1].name**

قبول الشراكة

**join.stages[1].summary**

قرار واضح وملاحظات عند الحاجة

**join.stages[1].title**

مراجعة طلب الشراكة

**join.stages[1].body**

تراجع جريء الطلب. يظهر القرار في الحساب، وتُوضّح التعديلات المطلوبة عند الحاجة.

**join.stages[1].status**

قيد المراجعة

**join.stages[1].rows[0]**

مراجعة البيانات

**join.stages[1].rows[1]**

قرار الشراكة

**join.stages[1].rows[2]**

ملاحظات محدّدة

**join.stages[2].name**

إعداد المزايا

**join.stages[2].summary**

المحتوى والشروط وطريقة الاستفادة

**join.stages[2].title**

إعداد طلب الإطلاق

**join.stages[2].body**

يُضيف الشريك نبذة العلامة والصور والمزايا، ويعاينها قبل الإرسال.

**join.stages[2].status**

قيد الإعداد

**join.stages[2].rows[0]**

الصفحة والصور

**join.stages[2].rows[1]**

المزايا والشروط

**join.stages[2].rows[2]**

معاينة المحتوى

**join.stages[3].name**

المراجعة والنشر

**join.stages[3].summary**

اعتماد الصفحة والمزايا الأولى معًا

**join.stages[3].title**

إطلاق المحتوى المعتمد

**join.stages[3].body**

تراجع جريء طلب الإطلاق. تُنشر الصفحة والمزايا الأولى معًا بعد الموافقة.

**join.stages[3].status**

بانتظار الاعتماد

**join.stages[3].rows[0]**

طلب إطلاق واحد

**join.stages[3].rows[1]**

مراجعة جريء

**join.stages[3].rows[2]**

نشر النسخة المعتمدة

**join.foot**

قبول الشراكة لا ينشر المحتوى تلقائيًا.

**join.next**

استعراض طرق الاستفادة

**benefit.title**

طريقة استفادة تناسب نشاطكم

**benefit.lead**

يحدّد الشريك مكان الاستفادة، وما يقدّمه العضو، وكيف تُؤكّد العملية.

**benefit.tabs[0]**

عبر الإنترنت

**benefit.tabs[1]**

حضوريًا

**benefit.tabs[2]**

خدمة أو تجربة

**benefit.audience**

الفئة المستفيدة

**benefit.method**

طريقة الاستفادة

**benefit.controls**

يحدّدها الشريك

**benefit.controlLabels[0]**

الجمهور

**benefit.controlLabels[1]**

المدة

**benefit.controlLabels[2]**

حدود الاستفادة

**benefit.controlLabels[3]**

الشروط

**benefit.codeTitle**

خيارات الرموز

**benefit.codeBody**

رمز مشترك، أو رموز فردية يضيفها الشريك، أو قسائم من جريء، أو رموز يصدرها نظام الشريك.

**benefit.action**

متابعة التحقّق والاستفادة

**benefit.methods[0].id**

digital

**benefit.methods[0].brand**

Notion

**benefit.methods[0].category**

أدوات العمل

**benefit.methods[0].title**

اشتراك رقمي للأعضاء

**benefit.methods[0].body**

تصوّر لاشتراك يفعّله العضو على موقع الشريك.

**benefit.methods[0].audience**

الشركات الناشئة

**benefit.methods[0].method**

رمز فردي

**benefit.methods[0].heading**

من حساب العضو إلى موقع الشريك

**benefit.methods[0].steps[0]**

يفتح العضو الميزة وشروطها في جريء.

**benefit.methods[0].steps[1]**

يحصل على رمزه المخصّص.

**benefit.methods[0].steps[2]**

يستخدمه على موقع الشريك.

**benefit.methods[0].note**

يُسجّل الاستخدام عند وصول تأكيد نظام الشريك، إذا كان الربط مفعّلًا.

**benefit.methods[0].token**

رمز العضو

**benefit.methods[0].verify**

التحقّق من الرمز

**benefit.methods[0].unit**

استخدام واحد

**benefit.methods[0].remaining**

0

**benefit.methods[0].remainingLabel**

المتبقي

**benefit.methods[0].verification**

رمز صالح وعضو مؤهل. لم تُسجّل استفادة بعد.

**benefit.methods[0].place**

في نظام الشريك

**benefit.methods[1].id**

venue

**benefit.methods[1].brand**

Regus

**benefit.methods[1].category**

مساحات العمل

**benefit.methods[1].title**

يومان في مساحة عمل

**benefit.methods[1].body**

تصوّر لميزة تُستخدم في المواقع التي يحدّدها الشريك.

**benefit.methods[1].audience**

الشركات الناشئة

**benefit.methods[1].method**

بطاقة العضوية

**benefit.methods[1].heading**

التحقّق عند الاستفادة

**benefit.methods[1].steps[0]**

يراجع العضو المواقع والشروط.

**benefit.methods[1].steps[1]**

يعرض بطاقته للتحقّق من أهليته.

**benefit.methods[1].steps[2]**

يؤكّد موظف مخوَّل الاستفادة.

**benefit.methods[1].note**

يمكن البدء بصفحة التحقّق في جريء دون ربط تقني.

**benefit.methods[1].token**

بطاقة العضوية

**benefit.methods[1].verify**

التحقّق من العضوية

**benefit.methods[1].unit**

يومان

**benefit.methods[1].remaining**

1

**benefit.methods[1].remainingLabel**

الأيام المتبقية

**benefit.methods[1].verification**

عضوية صالحة وميزة متاحة. المتبقي يومان، ولم تُسجّل استفادة.

**benefit.methods[1].place**

في صفحة التحقّق من جريء

**benefit.methods[2].id**

experience

**benefit.methods[2].brand**

Hilton

**benefit.methods[2].category**

الضيافة والتجارب

**benefit.methods[2].title**

تجربة ضيافة للأعضاء

**benefit.methods[2].body**

تصوّر لتجربة مختارة وفق شروط الشريك والتوفّر.

**benefit.methods[2].audience**

المستثمرون والشركات الناشئة

**benefit.methods[2].method**

قسيمة من جريء

**benefit.methods[2].heading**

قسيمة تُقدّم عند الاستفادة

**benefit.methods[2].steps[0]**

يراجع العضو التجربة وشروط الحجز.

**benefit.methods[2].steps[1]**

يحصل على قسيمته من جريء.

**benefit.methods[2].steps[2]**

تُفحص القسيمة ثم تُؤكّد الاستفادة.

**benefit.methods[2].note**

الحصول على القسيمة لا يعني استخدامها.

**benefit.methods[2].token**

قسيمة العضو

**benefit.methods[2].verify**

التحقّق من القسيمة

**benefit.methods[2].unit**

استخدام واحد

**benefit.methods[2].remaining**

0

**benefit.methods[2].remainingLabel**

المتبقي

**benefit.methods[2].verification**

قسيمة صالحة وعضو مؤهل. لم تُسجّل استفادة بعد.

**benefit.methods[2].place**

في صفحة التحقّق من جريء

**benefit.limit**

حدّ الاستفادة

**trust.title**

التحقّق وتأكيد الاستفادة

**trust.lead**

قد تظهر تفاصيل الميزة للزوار، بينما يحصل الأعضاء المؤهلون على الرموز وفق شروطها.

**trust.rules[0]**

عضوية صالحة

**trust.rules[1]**

جمهور محدّد

**trust.rules[2]**

مدة وحدود استخدام

**trust.note**

لضبط الاستفادة، يُستخدم التحقّق أو رموز فردية بضوابط مناسبة. الرمز المشترك وحده لا يمنع تداوله.

**trust.demo**

تجربة الاستفادة

**trust.initial**

تحقّقوا من الأهلية أولًا؛ لا يُسجَّل شيء في هذه المرحلة.

**trust.eligible**

مؤهل للاستفادة

**trust.confirm**

تأكيد الاستفادة

**trust.confirmed**

تم تسجيل الاستفادة

**trust.result**

حُدّث المتبقي وأُضيفت العملية إلى سجل النشاط.

**trust.repeat**

إعادة طلب التأكيد

**trust.repeated**

العملية مسجّلة مسبقًا

**trust.repeatNote**

أُعيدت النتيجة نفسها دون تسجيل استخدام إضافي.

**trust.reset**

بدء التجربة من جديد

**trust.seeActivity**

عرض العملية في السجل

**trust.demoNote**

محاكاة توضيحية، لا تسجّل عمليات فعلية.

**trust.reference**

مرجع العملية

**insights.title**

المتابعة والتحكّم

**insights.lead**

حالة المزايا ومخزون الرموز والاستفادات المؤكدة في مساحة واحدة.

**insights.dashboard**

نشاط المزايا

**insights.metrics[0][0]**

رموز ممنوحة

**insights.metrics[0][1]**

مُنحت للأعضاء، ولا تُحتسب استخدامًا

**insights.metrics[1][0]**

استفادات مؤكدة

**insights.metrics[1][1]**

تُسجَّل بعد التأكيد فقط

**insights.metrics[2][0]**

رموز متاحة

**insights.metrics[2][1]**

جاهزة لأعضاء جدد

**insights.chart**

الاستفادات المؤكدة

**insights.period**

ستة أسابيع توضيحية

**insights.history**

أحدث النشاط

**insights.today**

اليوم

**insights.yesterday**

أمس

**insights.rows[0][0]**

استفادة مؤكدة

**insights.rows[0][1]**

DEMO-024

**insights.rows[1][0]**

عُرض رمز

**insights.rows[1][1]**

الاستخدام غير مؤكّد

**insights.rows[2][0]**

أُلغي تسجيل استفادة

**insights.rows[2][1]**

السجل محفوظ

**insights.newRow**

من التجربة التوضيحية

**insights.principles[0][0]**

قياس واضح

**insights.principles[0][1]**

منح الرمز أو عرضه لا يثبت استخدامه.

**insights.principles[1][0]**

متابعة تراعي الخصوصية

**insights.principles[1][1]**

تقارير النشاط دون أسماء الأعضاء؛ بيانات التحقّق ضمن المسار المصرّح به.

**insights.principles[2][0]**

تحكّم بالمزايا

**insights.principles[2][1]**

إرسال تعديلات المحتوى للمراجعة، وإيقاف الطلبات الجديدة عند الحاجة.

**insights.next**

استعراض خيارات الربط

**connect.title**

الربط بحسب احتياجكم

**connect.lead**

يمكن البدء بصفحة التحقّق في جريء، أو ربط نظام الشريك بعد التجهيز والاختبار.

**connect.system**

نظام الشريك

**connect.systemNote**

متجر، حجز، اشتراك أو نظام خاص

**connect.clubNote**

العضوية والأهلية وسجل الاستفادة

**connect.optional**

ربط اختياري

**connect.functions[0]**

التحقّق

**connect.functions[1]**

إصدار الرموز

**connect.functions[2]**

تأكيد الاستفادة

**connect.steps[0][0]**

تحديد نطاق الربط

**connect.steps[0][1]**

ما ينفّذه النظام، وما يتم عبر جريء.

**connect.steps[1][0]**

تجهيز الوصول واختباره

**connect.steps[1][1]**

صلاحيات محدّدة ومفاتيح قابلة للإلغاء.

**connect.steps[2][0]**

متابعة الطلبات والنتائج

**connect.steps[2][1]**

إعادة المحاولة دون تكرار العملية.

**connect.detailTitle**

متطلبات الربط

**connect.detail**

تُحدّد نقاط الاتصال، وآلية إصدار الرموز والتأكيد، ومعالجة التعذّر بحسب إمكانات نظام الشريك. لا يفترض العرض ربطًا جاهزًا مع منصة محدّدة.

**connect.closing**

تحديد الميزة الأولى

**connect.closingBody**

أربع نقاط نتفق عليها قبل الإطلاق.

**connect.closingLabels[0]**

الميزة

**connect.closingLabels[1]**

الجمهور

**connect.closingLabels[2]**

الشروط

**connect.closingLabels[3]**

طريقة الاستفادة

**value.title**

لماذا تنضمّون إلى نادي جريء؟

**value.lead**

قدّموا مزاياكم لجمهور نوعي، وامنحوا علامتكم حضورًا في مجتمع جريء.

**value.items[0][0]**

جمهور نوعي

**value.items[0][1]**

مستثمرون موثوقون، بينهم أصحاب ملاءة مالية مرتفعة، وشركات ناشئة تبحث عن خدمات تدعم نموها.

**value.items[1][0]**

حضور في موقع جريء

**value.items[1][1]**

تظهر علامتكم ومزاياكم المعتمدة في نادي جريء، مع تفاصيل العرض وطريقة الاستفادة وروابطكم.

**value.items[2][0]**

ظهور خاص للمزايا المميزة

**value.items[2][1]**

قد يحظى الشركاء الذين يقدّمون مزايا مميزة بإبراز خاص داخل نادي جريء، بحسب قيمة الميزة وملاءمتها للأعضاء.

**value.next**

تعرّفوا على أعضاء نادي جريء
