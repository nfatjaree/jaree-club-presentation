# نادي جريء | تجربة الشريك

Editable source: `content/ar.json`

**lang**

ar

**dir**

rtl

**title**

نادي جريء | تجربة الشريك

**description**

تعرّفوا على رحلة الشريك في نادي جريء: الانضمام، وطرح المزايا، والاستفادة، والمتابعة، والربط.

**ui.club**

نادي جريء

**ui.partners**

للشركاء

**ui.concept**

تصوّر أوّلي

**ui.menu**

أقسام العرض

**ui.skip**

انتقل إلى المحتوى

**ui.pause**

إيقاف الحركة

**ui.play**

تشغيل الحركة

**ui.fullscreen**

ملء الشاشة

**ui.exitFullscreen**

الخروج من ملء الشاشة

**ui.previous**

القسم السابق

**ui.next**

القسم التالي

**ui.home**

بداية العرض

**ui.language**

English

**ui.alternate**

en.html

**ui.nextLabel**

التالي

**ui.backTop**

العودة إلى البداية

**ui.example**

مثال توضيحي

**ui.figures**

أرقام توضيحية

**ui.brandNote**

أمثلة توضيحية؛ لا تمثّل شراكات أو عروضًا فعلية من العلامات المعروضة.

**ui.continue**

متابعة التجربة

**ui.memberName**

اسم العضو

**ui.memberOf**

عضو في

**ui.membership**

العضوية

**ui.investor**

مستثمر

**ui.startup**

شركة ناشئة

**ui.download**

نسخة PDF

**ui.reducedMotion**

الحركة مخفّفة بحسب إعداد جهازك

**nav[0]**

التعريف

**nav[1]**

عن جريء

**nav[2]**

قيمة الشراكة

**nav[3]**

العضوية

**nav[4]**

الانضمام والنشر

**nav[5]**

طرق الاستفادة

**nav[6]**

التحقّق

**nav[7]**

المتابعة

**nav[8]**

الربط

**nav[9]**

الربط عمليًا

**intro.eyebrow**

تجربة الشريك

**intro.heading[0]**

نادي جريء

**intro.heading[1]**

للشركاء

**intro.lead**

قدّموا مزايا للمستثمرين والشركات الناشئة، مع إدارة واضحة للنشر والاستفادة والمتابعة.

**intro.action**

تعرّفوا على جريء

**intro.note**

تصوّر قيد التطوير. الواجهات والأمثلة التشغيلية توضيحية.

**intro.float1[0]**

اشتراك رقمي

**intro.float1[1]**

رمز مخصّص للعضو

**intro.float2[0]**

مساحة عمل

**intro.float2[1]**

التحقّق ببطاقة العضوية

**members.title**

العضوية والفئات المستفيدة

**members.lead**

ترتبط العضوية بحساب معتمد في جريء. يحدّد الشريك جمهور كل ميزة: المستثمرون، أو الشركات الناشئة، أو كلاهما.

**members.groups[0][0]**

الشركات الناشئة

**members.groups[0][1]**

عضوية يحملها ممثّل الشركة، ومزايا تدعم احتياجات العمل.

**members.groups[1][0]**

المستثمرون

**members.groups[1][1]**

مزايا وخدمات وتجارب تناسب أعمالهم واهتماماتهم.

**members.window**

حساب العضو

**members.heading**

بطاقة العضوية والمزايا

**members.body**

يجد العضو بطاقته، والمزايا المتاحة له، وشروط الاستفادة في حسابه.

**members.foot**

التحقّق من البطاقة لا يسجّل استفادة تلقائيًا.

**members.next**

الانضمام وإطلاق المزايا

**join.title**

من طلب الشراكة إلى النشر

**join.lead**

قدّم طلب الشراكة، وراجع بنود الاتفاقية ووقّعها مع جريء. بعدها جهّز ميزتك وأرسلها للمراجعة قبل النشر.

**join.stages[0].name**

طلب الشراكة

**join.stages[0].summary**

بيانات الجهة وفكرة الميزة

**join.stages[0].title**

عرّفنا بجهتك

**join.stages[0].body**

أضف اسم الجهة وشعارها وبيانات التواصل وفكرة الميزة. يمكنك الاستعانة بموقع الجهة أو ملفها لتعبئة الحقول، ثم مراجعتها قبل الإرسال.

**join.stages[0].status**

مسودة

**join.stages[0].rows[0]**

بيانات الجهة والشعار

**join.stages[0].rows[1]**

وسيلة التواصل وفكرة الميزة

**join.stages[0].rows[2]**

إشعار الاستلام بعد الإرسال

**join.stages[1].name**

مراجعة البنود

**join.stages[1].summary**

قرار واحد على الطلب والبنود

**join.stages[1].title**

اتفق مع جريء على البنود

**join.stages[1].body**

اقبل البنود كما هي أو اقترح إضافة بند أو تعديله أو حذفه ضمن الطلب نفسه. يراجع فريق جريء المقترحات، وقد يُطلب منك تأكيد الصيغة الناتجة قبل إعداد الاتفاقية.

**join.stages[1].status**

قيد المراجعة

**join.stages[1].rows[0]**

اقتراحات مرتبطة بطلب الشراكة

**join.stages[1].rows[1]**

قرار واحد من جريء

**join.stages[1].rows[2]**

تأكيد الصيغة النهائية عند الحاجة

**join.stages[2].name**

توقيع الاتفاقية

**join.stages[2].summary**

الشريك يوقّع أولًا، ثم جريء

**join.stages[2].title**

وقّعوا على النسخة نفسها

**join.stages[2].body**

يراجع الشريك الاتفاقية الجاهزة ويوقّعها داخل المنصة. يراجع ممثل جريء المخوّل النسخة ذاتها ويوقّعها، وتبقى النسخة النهائية متاحة للتنزيل للطرفين.

**join.stages[2].status**

الاتفاقية

**join.stages[2].rows[0]**

توقيع بخط اليد داخل الاتفاقية

**join.stages[2].rows[1]**

توقيع جريء على النسخة نفسها

**join.stages[2].rows[2]**

ملف PDF نهائي واحد للطرفين

**join.stages[3].name**

تجهيز الميزة والنشر

**join.stages[3].summary**

الاستفادة أولًا، ثم مراجعة النشر

**join.stages[3].title**

جهّز ميزتك الأولى

**join.stages[3].body**

بعد اكتمال الاتفاقية، جهّز صفحة الجهة والميزة وطريقة الاستفادة. عاين ما سيراه الأعضاء وأرسل طلب النشر للمراجعة. يفتح استيراد اتفاقية سارية وموقّعة مسبقًا مرحلة التجهيز بعد تحقّق جريء منها.

**join.stages[3].status**

تجهيز الميزة

**join.stages[3].rows[0]**

معاينة ما سيراه العضو

**join.stages[3].rows[1]**

إعداد التحقق أو الربط حسب طريقة الاستفادة

**join.stages[3].rows[2]**

النشر بعد اعتماد المراجعة

**join.foot**

توقيع الاتفاقية يفتح أدوات التجهيز. تظهر الميزة للأعضاء بعد اعتماد طلب النشر.

**join.next**

استعراض طرق الاستفادة

**join.handout[0]**

أضف بيانات الجهة وفكرة الميزة. يمكنك مراجعة اقتراحات التعبئة من موقع الجهة أو ملفها.

**join.handout[1]**

اقبل البنود أو اقترح إضافتها أو تعديلها أو حذفها ضمن الطلب نفسه.

**join.handout[2]**

يوقّع الشريك، ثم يوقّع ممثل جريء النسخة نفسها. يتاح ملف نهائي واحد للطرفين.

**join.handout[3]**

افتح التجهيز بعد التوقيع أو توثيق اتفاقية سارية. عاين الميزة وأرسلها للنشر.

**join.examples.tabs**

خطوات الانضمام والنشر

**join.examples.label**

معاينة داخل العرض

**join.examples.application.title**

طلب شراكة

**join.examples.application.status**

مسودة

**join.examples.application.fields[0][0]**

اسم الجهة

**join.examples.application.fields[0][1]**

مساحة أفق

**join.examples.application.fields[1][0]**

مجال النشاط

**join.examples.application.fields[1][1]**

مساحات العمل المشتركة

**join.examples.application.fields[2][0]**

الميزة المقترحة

**join.examples.application.fields[2][1]**

يوم عمل مجاني كل شهر

**join.examples.application.help**

ساعدني في التعبئة

**join.examples.application.source**

اقتراحات من ملف الجهة التجريبي

**join.examples.application.intro**

اختر ما تريد تطبيقه. يمكنك تعديل الحقول بعد التعبئة.

**join.examples.application.apply**

طبّق الاقتراحات

**join.examples.application.applied**

تمت تعبئة الحقول المختارة.

**join.examples.application.placeholders[0]**

مثل اسم شركتك

**join.examples.application.placeholders[1]**

مثل الضيافة أو التقنية

**join.examples.application.placeholders[2]**

صف ما سيحصل عليه العضو

**join.examples.terms.title**

مراجعة البنود

**join.examples.terms.status**

وافق جريء على الاقتراح

**join.examples.terms.clause**

مثال على تعديل بند

**join.examples.terms.before**

النص قبل التعديل

**join.examples.terms.old**

تسري الميزة في جميع الفروع.

**join.examples.terms.after**

الصيغة المتفق عليها

**join.examples.terms.new**

تسري الميزة في فرع الرياض بعد الحجز.

**join.examples.terms.compare**

قارن بالنص السابق

**join.examples.terms.next**

عند تأكيد البنود، تُجهّز الاتفاقية للتوقيع.

**join.examples.signing.title**

جرّب توقيع الاتفاقية

**join.examples.signing.status**

تجربة تفاعلية

**join.examples.signing.help**

ارسم داخل الخانة بإصبعك أو قلمك أو الماوس. هذه تجربة فقط ولا يُرسل توقيعك.

**join.examples.signing.pad**

مساحة رسم التوقيع

**join.examples.signing.placeholder**

ارسم هنا

**join.examples.signing.sample**

استخدم توقيعًا تجريبيًا

**join.examples.signing.clear**

امسح

**join.examples.signing.sign**

اعتمد توقيع الشريك

**join.examples.signing.countersign**

حاكِ توقيع جريء

**join.examples.signing.reset**

أعد التجربة

**join.examples.signing.waiting**

وقّع الشريك. بانتظار توقيع جريء على النسخة نفسها.

**join.examples.signing.complete**

اكتملت المحاكاة. وقّع الطرفان على النسخة نفسها.

**join.examples.benefit.title**

محرّر الميزة

**join.examples.benefit.status**

قبل النشر

**join.examples.benefit.brand**

مساحة أفق

**join.examples.benefit.offer**

يوم عمل مجاني كل شهر

**join.examples.benefit.details**

للمستثمرين والشركات الناشئة

**join.examples.benefit.action**

تحجز زيارتك وتعرض بطاقة النادي عند الوصول.

**join.examples.benefit.agreed**

العرض المتفق عليه

**join.examples.benefit.audience**

الفئة المستفيدة

**join.examples.benefit.where**

مكان الاستفادة

**join.examples.benefit.branch**

فرع الرياض

**join.examples.benefit.preview**

عاين ما سيراه العضو

**join.examples.benefit.next**

ترسل الميزة إلى جريء للمراجعة قبل نشرها.

**benefit.title**

طريقة استفادة تناسب نشاطكم

**benefit.lead**

يحدّد الشريك مكان الاستفادة، وما يقدّمه العضو، وكيف تُؤكّد العملية.

**benefit.tabs[0]**

عبر الإنترنت

**benefit.tabs[1]**

حضوريًا

**benefit.tabs[2]**

خدمة أو تجربة

**benefit.audience**

الفئة المستفيدة

**benefit.method**

طريقة الاستفادة

**benefit.controls**

يحدّدها الشريك

**benefit.controlLabels[0]**

الجمهور

**benefit.controlLabels[1]**

المدة

**benefit.controlLabels[2]**

حدود الاستفادة

**benefit.controlLabels[3]**

الشروط

**benefit.codeTitle**

خيارات الرموز

**benefit.codeBody**

رمز مشترك، أو رموز فردية يضيفها الشريك، أو قسائم من جريء، أو رموز يصدرها نظام الشريك.

**benefit.action**

متابعة التحقّق والاستفادة

**benefit.methods[0].id**

digital

**benefit.methods[0].brand**

Notion

**benefit.methods[0].category**

أدوات العمل

**benefit.methods[0].title**

اشتراك رقمي للأعضاء

**benefit.methods[0].body**

تصوّر لاشتراك يفعّله العضو على موقع الشريك.

**benefit.methods[0].audience**

الشركات الناشئة

**benefit.methods[0].method**

رمز فردي

**benefit.methods[0].heading**

من حساب العضو إلى موقع الشريك

**benefit.methods[0].steps[0]**

يفتح العضو الميزة وشروطها في جريء.

**benefit.methods[0].steps[1]**

يحصل على رمزه المخصّص.

**benefit.methods[0].steps[2]**

يستخدمه على موقع الشريك.

**benefit.methods[0].note**

يُسجّل الاستخدام عند وصول تأكيد نظام الشريك، إذا كان الربط مفعّلًا.

**benefit.methods[0].token**

رمز العضو

**benefit.methods[0].verify**

التحقّق من الرمز

**benefit.methods[0].unit**

استخدام واحد

**benefit.methods[0].remaining**

0

**benefit.methods[0].remainingLabel**

المتبقي

**benefit.methods[0].verification**

رمز صالح وعضو مؤهل. لم تُسجّل استفادة بعد.

**benefit.methods[0].place**

في نظام الشريك

**benefit.methods[1].id**

venue

**benefit.methods[1].brand**

Regus

**benefit.methods[1].category**

مساحات العمل

**benefit.methods[1].title**

يومان في مساحة عمل

**benefit.methods[1].body**

تصوّر لميزة تُستخدم في المواقع التي يحدّدها الشريك.

**benefit.methods[1].audience**

الشركات الناشئة

**benefit.methods[1].method**

بطاقة العضوية

**benefit.methods[1].heading**

التحقّق عند الاستفادة

**benefit.methods[1].steps[0]**

يراجع العضو المواقع والشروط.

**benefit.methods[1].steps[1]**

يعرض بطاقته للتحقّق من أهليته.

**benefit.methods[1].steps[2]**

يؤكّد موظف مخوَّل الاستفادة.

**benefit.methods[1].note**

يمكن البدء بصفحة التحقّق في جريء دون ربط تقني.

**benefit.methods[1].token**

بطاقة العضوية

**benefit.methods[1].verify**

التحقّق من العضوية

**benefit.methods[1].unit**

يومان

**benefit.methods[1].remaining**

1

**benefit.methods[1].remainingLabel**

الأيام المتبقية

**benefit.methods[1].verification**

عضوية صالحة وميزة متاحة. المتبقي يومان، ولم تُسجّل استفادة.

**benefit.methods[1].place**

في صفحة التحقّق من جريء

**benefit.methods[2].id**

experience

**benefit.methods[2].brand**

Hilton

**benefit.methods[2].category**

الضيافة والتجارب

**benefit.methods[2].title**

تجربة ضيافة للأعضاء

**benefit.methods[2].body**

تصوّر لتجربة مختارة وفق شروط الشريك والتوفّر.

**benefit.methods[2].audience**

المستثمرون والشركات الناشئة

**benefit.methods[2].method**

قسيمة من جريء

**benefit.methods[2].heading**

قسيمة تُقدّم عند الاستفادة

**benefit.methods[2].steps[0]**

يراجع العضو التجربة وشروط الحجز.

**benefit.methods[2].steps[1]**

يحصل على قسيمته من جريء.

**benefit.methods[2].steps[2]**

تُفحص القسيمة ثم تُؤكّد الاستفادة.

**benefit.methods[2].note**

الحصول على القسيمة لا يعني استخدامها.

**benefit.methods[2].token**

قسيمة العضو

**benefit.methods[2].verify**

التحقّق من القسيمة

**benefit.methods[2].unit**

استخدام واحد

**benefit.methods[2].remaining**

0

**benefit.methods[2].remainingLabel**

المتبقي

**benefit.methods[2].verification**

قسيمة صالحة وعضو مؤهل. لم تُسجّل استفادة بعد.

**benefit.methods[2].place**

في صفحة التحقّق من جريء

**benefit.limit**

حدّ الاستفادة

**trust.title**

التحقّق وتأكيد الاستفادة

**trust.lead**

قد تظهر تفاصيل الميزة للزوار، بينما يحصل الأعضاء المؤهلون على الرموز وفق شروطها.

**trust.rules[0]**

عضوية صالحة

**trust.rules[1]**

جمهور محدّد

**trust.rules[2]**

مدة وحدود استخدام

**trust.note**

لضبط الاستفادة، يُستخدم التحقّق أو رموز فردية بضوابط مناسبة. الرمز المشترك وحده لا يمنع تداوله.

**trust.demo**

تجربة الاستفادة

**trust.initial**

تحقّقوا من الأهلية أولًا. لا تُسجّل استفادة في هذه الخطوة.

**trust.eligible**

مؤهل للاستفادة

**trust.confirm**

تأكيد الاستفادة

**trust.confirmed**

تم تسجيل الاستفادة

**trust.result**

حُدّث المتبقي وأُضيفت العملية إلى سجل النشاط.

**trust.repeat**

إعادة طلب التأكيد

**trust.repeated**

العملية مسجّلة مسبقًا

**trust.repeatNote**

أُعيدت النتيجة نفسها دون تسجيل استخدام إضافي.

**trust.reset**

بدء التجربة من جديد

**trust.seeActivity**

عرض العملية في السجل

**trust.demoNote**

محاكاة توضيحية، لا تسجّل عمليات فعلية.

**trust.reference**

مرجع العملية

**insights.title**

المتابعة والتحكّم

**insights.lead**

تُعرض مشاهدات الميزة والرموز الصادرة والاستفادات المؤكدة كلٌّ على حدة. يُسجَّل الاستخدام بعد تأكيد الاستفادة، ويظهر رصيد الرموز للمزايا التي تستخدم مخزونًا.

**insights.dashboard**

نشاط المزايا

**insights.metrics[0][0]**

الرموز الصادرة

**insights.metrics[0][1]**

مُنحت للأعضاء، ولا تُحتسب استخدامًا

**insights.metrics[1][0]**

استفادات مؤكدة

**insights.metrics[1][1]**

تُسجَّل بعد التأكيد فقط

**insights.metrics[2][0]**

رموز متاحة

**insights.metrics[2][1]**

جاهزة لأعضاء جدد

**insights.chart**

الاستفادات المؤكدة

**insights.period**

ستة أسابيع توضيحية

**insights.history**

أحدث النشاط

**insights.today**

اليوم

**insights.yesterday**

أمس

**insights.rows[0][0]**

استفادة مؤكدة

**insights.rows[0][1]**

DEMO-024

**insights.rows[1][0]**

عُرض رمز

**insights.rows[1][1]**

الاستخدام غير مؤكّد

**insights.rows[2][0]**

أُلغي تسجيل استفادة

**insights.rows[2][1]**

السجل محفوظ

**insights.newRow**

من التجربة التوضيحية

**insights.principles[0][0]**

قياس واضح

**insights.principles[0][1]**

إصدار الرمز أو عرضه لا يُحتسب استفادة مؤكدة.

**insights.principles[1][0]**

متابعة تراعي الخصوصية

**insights.principles[1][1]**

تقارير النشاط دون أسماء الأعضاء؛ بيانات التحقّق ضمن المسار المصرّح به.

**insights.principles[2][0]**

تحكّم بالمزايا

**insights.principles[2][1]**

إرسال تعديلات المحتوى للمراجعة، وإيقاف الطلبات الجديدة عند الحاجة.

**insights.next**

استعراض خيارات الربط

**connect.title**

ربط يناسب طريقة عملكم

**connect.lead**

يرتبط نظامكم بجريء عبر API للتحقّق من الأهلية وتسجيل الاستفادة، أو إصدار الرموز عند الطلب.

**connect.system**

نظام الشريك

**connect.systemNote**

متجر، حجز، اشتراك أو نظام خاص

**connect.clubNote**

الأهلية والرموز وسجل الاستفادة

**connect.optional**

HTTPS · API

**connect.functions[0]**

Bearer API keys

**connect.functions[1]**

HMAC-SHA256

**connect.functions[2]**

Idempotency-Key

**connect.steps[0][0]**

وصول بصلاحيات محدّدة

**connect.steps[0][1]**

مفتاح API للتحقّق فقط، أو للتحقّق وتأكيد الاستفادة. يُحفظ في خادمكم ويمكن إلغاؤه.

**connect.steps[1][0]**

اختبار قبل التفعيل

**connect.steps[1][1]**

يُختبر الربط بحسب طريقة تقديم الميزة قبل إرسالها للمراجعة.

**connect.steps[2][0]**

متابعة كل عملية

**connect.steps[2][1]**

يعرض السجل نتيجة كل طلب. وعند انقطاع الاتصال، يُعاد الطلب نفسه دون احتساب الاستفادة مرتين.

**connect.detailTitle**

خيارات الرموز ومتطلبات الربط

**connect.detail**

يمكن رفع رموزكم الجاهزة بملف CSV، أو ربط نظامكم لإصدارها عند الطلب. ويمكن استخدام صفحة التحقّق في جريء دون ربط تقني. يُجهّز الربط بحسب نظامكم؛ لا يتضمّن العرض موصّلات جاهزة لمنصات تجارية محدّدة.

**connect.closing**

تحديد الميزة الأولى

**connect.closingBody**

أربع نقاط نتفق عليها قبل الإطلاق.

**connect.closingLabels[0]**

الميزة

**connect.closingLabels[1]**

الجمهور

**connect.closingLabels[2]**

الشروط

**connect.closingLabels[3]**

طريقة الاستفادة

**value.title**

لماذا تنضمّون إلى نادي جريء؟

**value.lead**

قدّموا مزاياكم لجمهور نوعي، وامنحوا علامتكم حضورًا في مجتمع جريء.

**value.items[0][0]**

جمهور نوعي

**value.items[0][1]**

مستثمرون موثوقون، بينهم أصحاب ملاءة مالية مرتفعة، وشركات ناشئة تبحث عن خدمات تدعم نموها.

**value.items[1][0]**

حضور في موقع جريء

**value.items[1][1]**

تظهر علامتكم ومزاياكم المعتمدة في نادي جريء، مع تفاصيل العرض وطريقة الاستفادة وروابطكم.

**value.items[2][0]**

ظهور خاص للمزايا المميزة

**value.items[2][1]**

قد يحظى الشركاء الذين يقدّمون مزايا مميزة بإبراز خاص داخل نادي جريء، بحسب قيمة الميزة وملاءمتها للأعضاء.

**value.next**

تعرّفوا على أعضاء نادي جريء

**value.showcase.title**

علامتكم ضمن تجربة الأعضاء

**value.showcase.body**

تظهر علامتكم ضمن المزايا المعتمدة، مع محتوى يوضح قيمتها وطريقة الاستفادة منها. وقد تحظى المزايا الأبرز بمساحة ظهور خاصة.

**value.showcase.featured**

ظهور مميز

**value.showcase.view**

استكشفوا المثال

**value.showcase.notion**

أدوات لفريقكم وأفكاركم

**value.showcase.regus**

مساحات للعمل والاجتماع

**value.showcase.hilton**

تجارب ضيافة للأعضاء

**value.showcase.audience**

للشركات الناشئة

**about.title**

جريء. مجتمع منتقى للاستثمار والأعمال.

**about.lead**

منصة سعودية تربط مستثمرين معتمدين ذوي ملاءة مالية عالية بشركات ناشئة واعدة، وتتيح لهم استكشاف فرص الاستثمار وبناء علاقات الأعمال.

**about.stats[0][0]**

180

**about.stats[0][1]**

مستثمرًا مقبولًا

**about.stats[1][0]**

1,000+

**about.stats[1][1]**

طلب انضمام من مستثمرين

**about.selection**

الانضمام بالقبول، بعد مراجعة الأهلية والبيانات.

**about.source**

الأرقام من الملف التعريفي لجريء.

**about.items[0][0]**

مستثمرون ذوو ملاءة مالية عالية

**about.items[0][1]**

مستثمرون معتمدون اختارتهم جريء بعد مراجعة الأهلية والهوية والملاءة المالية.

**about.items[1][0]**

شركات ناشئة واعدة

**about.items[1][1]**

شركات ناشئة ذات إمكانات نمو، تلتقي في جريء بمستثمرين مؤهّلين لاستكشاف فرص الاستثمار.

**scenarios.title**

كيف يرتبط نظامكم بجريء؟

**scenarios.lead**

ثلاث عمليات: التحقّق من الأهلية، وتأكيد الاستفادة، وإصدار الرموز عند الطلب.

**scenarios.note**

منح الرمز أو عرضه لا يُحتسب استفادة. تُسجّل الاستفادة عند تأكيدها.

**scenarios.requestLabel**

الطلب

**scenarios.responseLabel**

مقتطف من الاستجابة

**scenarios.baseLabel**

مسار واجهة جريء

**scenarios.exampleNote**

مقتطفات من الربط الجاري تطويره واختباره، بقيم تجريبية لا تتضمّن مفاتيح فعلية أو بيانات أعضاء.

**scenarios.items[0].id**

verify

**scenarios.items[0].title**

التحقّق من الأهلية

**scenarios.items[0].direction**

نظامكم ↔ جريء

**scenarios.items[0].body**

يقدّم العضو بطاقته أو رمزه. يتحقّق نظامكم عبر جريء من أهليته للميزة والحدّ المتاح، دون تسجيل استفادة.

**scenarios.items[0].steps[0]**

بطاقة أو رمز

**scenarios.items[0].steps[1]**

تحقّق عبر جريء

**scenarios.items[0].steps[2]**

نتيجة الأهلية

**scenarios.items[0].request**

POST /codes/check
Authorization: Bearer <partner-key>
Content-Type: application/json

{"code":"EXAMPLE-1001"}

**scenarios.items[0].response**

{
  "valid": true,
  "state": "LIVE",
  "benefit": {
    "unavailable": null,
    "confirmVia": "SYSTEM",
    "allowance": {"remaining": 1}
  }
}

**scenarios.items[0].outcome**

الميزة متاحة للتأكيد عبر نظامكم في هذا المثال. لا تُطبّق إلا بعد نجاح طلب التأكيد.

**scenarios.items[0].detail**

للتحقّق بالبطاقة: POST /cards/check. أمّا قسائم جريء فتُفحص وتُؤكّد عبر صفحة التحقّق في جريء.

**scenarios.items[0].summary**

النتيجة مبدئية؛ تُطبّق الميزة فقط بعد نجاح تأكيد الاستفادة.

**scenarios.items[1].id**

confirm

**scenarios.items[1].title**

تأكيد الاستفادة

**scenarios.items[1].direction**

نظامكم ← جريء ← سجل الاستفادة

**scenarios.items[1].body**

قبل إتمام العملية، يطلب نظامكم تأكيد الاستفادة من جريء. بعد نجاح التأكيد، تُطبّق الميزة وتُسجّل مرة واحدة.

**scenarios.items[1].steps[0]**

طلب التأكيد

**scenarios.items[1].steps[1]**

تأكيد ناجح

**scenarios.items[1].steps[2]**

إتمام العملية

**scenarios.items[1].request**

POST /uses
Authorization: Bearer <partner-key>
Idempotency-Key: order-10483

{"code":"EXAMPLE-1001",
 "orderReference":"ORDER-10483"}

**scenarios.items[1].response**

201 Created
{"status":"CONFIRMED"}

200 OK
{"status":"CONFIRMED","replayed":true}

**scenarios.items[1].outcome**

201 لتأكيد جديد؛ و200 مع CONFIRMED لإعادة نتيجة ناجحة. الاستجابة 422 تعني رفض التأكيد دون تسجيل استفادة.

**scenarios.items[1].detail**

تُعاد المحاولة بالطلب ومعرّف Idempotency-Key نفسيهما. يحدّد orderReference العملية لديكم، ويمنع تكرارها للعضو والميزة نفسيهما عند استخدام مساري التأكيد.

**scenarios.items[1].summary**

إذا رُفض التأكيد، لا تُطبّق الميزة. إعادة الطلب نفسه لا تعني استفادة جديدة.

**scenarios.items[2].id**

issue

**scenarios.items[2].title**

إصدار رمز من نظامكم

**scenarios.items[2].direction**

جريء ← نظامكم ← جريء

**scenarios.items[2].body**

عندما يطلب العضو رمزه في جريء، تطلبه جريء من نظامكم ثم تعرضه في حسابه.

**scenarios.items[2].steps[0]**

طلب العضو

**scenarios.items[2].steps[1]**

إصدار من نظامكم

**scenarios.items[2].steps[2]**

ظهور الرمز في جريء

**scenarios.items[2].request**

POST https://partner.example/jaree/codes
webhook-id: <request-id>
webhook-timestamp: <unix-seconds>
webhook-signature: v1,<signature>

**scenarios.items[2].response**

200 OK
{
  "code": "EXAMPLE-1001",
  "expiresOn": "2027-06-30"
}

**scenarios.items[2].outcome**

يعود الرمز إلى العضو. إصداره وحده لا يُسجّل استفادة.

**scenarios.items[2].detail**

يتحقّق نظامكم من توقيع HMAC-SHA256 والطابع الزمني قبل إصدار الرمز. عند تعذّر الاستجابة، تعيد جريء المحاولة بمعرّف الطلب نفسه؛ يجب أن يعيد نظامكم الرمز نفسه دون إصدار مكرّر.

**scenarios.items[2].summary**

إذا أعادت جريء الطلب، يعيد نظامكم الرمز نفسه للعضو.

**scenarios.technicalLabel**

للفريق التقني: أمثلة API

**scenarios.pdfTechnicalLabel**

للفريق التقني: أمثلة الطلبات والاستجابات في العرض التفاعلي.
